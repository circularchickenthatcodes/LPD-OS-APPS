-- Simple Calculator App for LPD-OS

local function draw_button(x, y, w, h, text, color, text_color)
    fillRect(x, y, w, h, color)
    rect(x, y, w, h, WHITE)
    setTextSize(2)
    setTextColor(text_color)
    local text_width = #text * 12 -- Approx width for text size 2
    printAt(x + (w - text_width) / 2, y + (h - 16) / 2, text) -- 16 is approx text height
end

local function is_point_in_rect(px, py, rx, ry, rw, rh)
    return px >= rx and px <= rx + rw and py >= ry and py <= ry + rh
end

local function run_calculator()
    local display_value = "0"
    local current_operator = nil
    local first_operand = nil
    local waiting_for_second_operand = false

    local button_layout = {
        {"C", "/", "*", "-"},
        {"7", "8", "9", "+"},
        {"4", "5", "6", "="},
        {"1", "2", "3", ""}, -- Empty for now, will add 0 and .
        {"0", ".", "", ""}
    }

    local button_width = 100
    local button_height = 60
    local start_x = 200
    local start_y = 150
    local padding = 10

    local function update_display()
        cls(BLACK)
        fillRect(start_x, start_y - 70, button_width * 4 + padding * 3, 60, DARKGREY)
        rect(start_x, start_y - 70, button_width * 4 + padding * 3, 60, WHITE)
        setTextSize(3)
        setTextColor(WHITE)
        local text_w = #display_value * 18 -- Approx width for text size 3
        printAt(start_x + (button_width * 4 + padding * 3) - text_w - 10, start_y - 55, display_value)
        flush()
    end

    local function calculate()
        local result = 0
        local op1 = tonumber(first_operand)
        local op2 = tonumber(display_value)
        if current_operator == "+" then
            result = op1 + op2
        elseif current_operator == "-" then
            result = op1 - op2
        elseif current_operator == "*" then
            result = op1 * op2
        elseif current_operator == "/" then
            if op2 ~= 0 then
                result = op1 / op2
            else
                return "Error"
            end
        end
        return tostring(result)
    end

    showMouse(true)
    update_display()

    while true do
        local mx, my, ml, mr, sc, lc, rc = getMouse()
        local k = getKeyPress()

        if k == 0x29 then -- ESC key to quit
            break
        end

        if lc then
            local button_clicked = false
            for row = 0, 4 do
                for col = 0, 3 do
                    local btn_text = button_layout[row + 1][col + 1]
                    if btn_text ~= "" then
                        local btn_x = start_x + col * (button_width + padding)
                        local btn_y = start_y + row * (button_height + padding)
                        if is_point_in_rect(mx, my, btn_x, btn_y, button_width, button_height) then
                            button_clicked = true
                            if tonumber(btn_text) or btn_text == "." then
                                if waiting_for_second_operand then
                                    display_value = btn_text
                                    waiting_for_second_operand = false
                                else
                                    if display_value == "0" and btn_text ~= "." then
                                        display_value = btn_text
                                    else
                                        display_value = display_value .. btn_text
                                    end
                                end
                            elseif btn_text == "C" then
                                display_value = "0"
                                first_operand = nil
                                current_operator = nil
                                waiting_for_second_operand = false
                            elseif btn_text == "=" then
                                if first_operand and current_operator then
                                    display_value = calculate()
                                    first_operand = nil
                                    current_operator = nil
                                    waiting_for_second_operand = true
                                end
                            else -- Operator
                                if first_operand and current_operator and not waiting_for_second_operand then
                                    display_value = calculate()
                                    first_operand = display_value
                                else
                                    first_operand = display_value
                                end
                                current_operator = btn_text
                                waiting_for_second_operand = true
                            end
                            update_display()
                            break
                        end
                    end
                end
                if button_clicked then break end
            end
        end

        -- Draw buttons
        for row = 0, 4 do
            for col = 0, 3 do
                local btn_text = button_layout[row + 1][col + 1]
                if btn_text ~= "" then
                    local btn_x = start_x + col * (button_width + padding)
                    local btn_y = start_y + row * (button_height + padding)
                    local btn_color = BLUE
                    local text_color = WHITE
                    if btn_text == "C" then btn_color = RED end
                    if btn_text == "=" then btn_color = GREEN end
                    if tonumber(btn_text) or btn_text == "." then btn_color = DARKGREY end
                    
                    draw_button(btn_x, btn_y, button_width, button_height, btn_text, btn_color, text_color)
                end
            end
        end
        
        flush()
        delay(10)
    end

    showMouse(false)
    cls(BLACK)
    flush()
end

run_calculator()
