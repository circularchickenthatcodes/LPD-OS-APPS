-- Modern, Polished, Accurate Minesweeper for ESP32-P4 OS
-- Screen resolution: SCREEN_W (800) x SCREEN_H (480)
-- Guaranteed safe first click (always lands on a 0-empty space)

-- 1. Theme Configuration (Using your raw global colors and rgb converter)
local COLOR_BG       = rgb(30, 30, 36)     -- Deep Slate Blue
local COLOR_GRID_BG  = rgb(21, 21, 24)     -- Darker shadow border
local COLOR_HIDDEN   = rgb(74, 85, 104)    -- Beveled unrevealed tile
local COLOR_LIGHT    = rgb(113, 128, 150)  -- Highlight edge for 3D effect
local COLOR_REVEALED = rgb(226, 232, 240)  -- Flat paper-white revealed tile
local COLOR_MINE_BG  = rgb(245, 101, 101)  -- Soft Red for exploded mine

-- Number colors (Classic, clean palette)
local NUM_COLORS = {
    rgb(49, 130, 206),  -- 1: Blue
    rgb(56, 161, 105),  -- 2: Green
    rgb(229, 62, 62),   -- 3: Red
    rgb(116, 66, 196),  -- 4: Purple
    rgb(197, 48, 48),   -- 5: Maroon
    rgb(49, 151, 149),  -- 6: Teal
    rgb(45, 55, 72),    -- 7: Black
    rgb(113, 128, 150)  -- 8: Gray
}

-- 2. Game Sizing & Layout Setup
local COLS = 14
local ROWS = 8
local CELL_SIZE = 44
local PAD = 2

-- Center the grid on the 800x480 panel dynamically
local GRID_W = COLS * CELL_SIZE
local GRID_H = ROWS * CELL_SIZE
local START_X = math.floor((SCREEN_W - GRID_W) / 2)
local START_Y = 65
local TOTAL_MINES = 18

local board = {}
local gameState = "PLAYING" -- "PLAYING", "WON", "LOST"
local flagMode = false
local mineTriggeredR, mineTriggeredC = 0, 0
local firstClickDone = false -- Tracks if we need to generate mines

-- 3. Game Logic Functions
-- Allocates a clean, empty board structure
local function buildEmptyBoard()
    board = {}
    for r = 1, ROWS do
        board[r] = {}
        for c = 1, COLS do
            board[r][c] = {
                isMine = false,
                isRevealed = false,
                isFlagged = false,
                count = 0
            }
        end
    end
end

function initGame()
    gameState = "PLAYING"
    flagMode = false
    mineTriggeredR, mineTriggeredC = 0, 0
    firstClickDone = false
    buildEmptyBoard()
end

-- Generates mines only AFTER the first click, ensuring startR and startC neighborhood is clear
function generateMines(startR, startC)
    local planted = 0
    math.randomseed(millis() + getPixel(10, 10)) -- Entropy seed adjustment
    
    while planted < TOTAL_MINES do
        local r = math.random(1, ROWS)
        local c = math.random(1, COLS)
        
        -- Check if target is inside the 3x3 forbidden safety zone around first click
        local inSafetyZone = false
        if math.abs(r - startR) <= 1 and math.abs(c - startC) <= 1 then
            inSafetyZone = true
        end

        -- Only place mine if it is not a mine already, and outside first click neighborhood
        if not board[r][c].isMine and not inSafetyZone then
            board[r][c].isMine = true
            planted = planted + 1
        end
    end

    -- Compute neighbors strictly respecting grid boundaries
    for r = 1, ROWS do
        for c = 1, COLS do
            if not board[r][c].isMine then
                local num = 0
                for dr = -1, 1 do
                    for dc = -1, 1 do
                        local nr = r + dr
                        local nc = c + dc
                        if nr >= 1 and nr <= ROWS and nc >= 1 and nc <= COLS then
                            if board[nr][nc].isMine then 
                                num = num + 1 
                            end
                        end
                    end
                end
                board[r][c].count = num
            end
        end
    end
end

-- Cascade Reveal (Flood Fill)
function reveal(r, c)
    if r < 1 or r > ROWS or c < 1 or c > COLS then return end
    
    local cell = board[r][c]
    if cell.isRevealed or cell.isFlagged then return end

    cell.isRevealed = true

    if cell.isMine then
        gameState = "LOST"
        mineTriggeredR, mineTriggeredC = r, c
        revealAllMines()
        return
    end

    if cell.count == 0 then
        for dr = -1, 1 do
            for dc = -1, 1 do
                reveal(r + dr, c + dc)
            end
        end
    end
    checkWin()
end

function revealAllMines()
    for r = 1, ROWS do
        for c = 1, COLS do
            if board[r][c].isMine then board[r][c].isRevealed = true end
        end
    end
end

function checkWin()
    for r = 1, ROWS do
        for c = 1, COLS do
            if not board[r][c].isMine and not board[r][c].isRevealed then return end
        end
    end
    gameState = "WON"
end

-- 4. Drawing Utilities
function drawButton(x, y, w, h, label, isAct, bgCol)
    local border = isAct and rgb(236, 201, 75) or rgb(74, 85, 104)
    fillRect(x, y, w, h, border)
    fillRect(x + 2, y + 2, w - 4, h - 4, bgCol)
    printAt(x + math.floor(w / 2) - (#label * 4), y + math.floor(h / 2) - 4, label, WHITE, 1)
end

function renderUI()
    cls(COLOR_BG)
    
    -- Top Header Panel layout
    fillRect(0, 0, SCREEN_W, 50, rgb(21, 21, 24))
    fillRect(0, 48, SCREEN_W, 2, rgb(45, 55, 72))

    -- Dynamic Text Information Headers via printAt
    if gameState == "PLAYING" then
        printAt(30, 18, "MINESWEEPER", rgb(236, 201, 75), 1)
        printAt(650, 18, "MINES: " .. TOTAL_MINES, WHITE, 1)
    elseif gameState == "WON" then
        printAt(30, 18, "VICTORY! TAP TO RESTART", rgb(72, 187, 120), 1)
    else
        printAt(30, 18, "GAME OVER! TAP TO RESTART", rgb(245, 101, 101), 1)
    end

    -- Outer bounding grid outline tray
    rect(START_X - 3, START_Y - 3, GRID_W + 6, GRID_H + 6, COLOR_GRID_BG)

    -- Loop over and render all matrix board cell tiles
    for r = 1, ROWS do
        for c = 1, COLS do
            local cx = START_X + (c - 1) * CELL_SIZE
            local cy = START_Y + (r - 1) * CELL_SIZE
            local cell = board[r][c]

            if cell.isRevealed then
                if cell.isMine then
                    local mCol = (r == mineTriggeredR and c == mineTriggeredC) and COLOR_MINE_BG or rgb(45, 55, 72)
                    fillRect(cx + PAD, cy + PAD, CELL_SIZE - (PAD*2), CELL_SIZE - (PAD*2), mCol)
                    printAt(cx + 18, cy + 16, "*", WHITE, 1)
                else
                    fillRect(cx + PAD, cy + PAD, CELL_SIZE - (PAD*2), CELL_SIZE - (PAD*2), COLOR_REVEALED)
                    if cell.count > 0 then
                        local tc = NUM_COLORS[cell.count] or WHITE
                        printAt(cx + 18, cy + 16, tostring(cell.count), tc, 1)
                    end
                end
            else
                -- 3D Beveled Design Configuration
                fillRect(cx + PAD, cy + PAD, CELL_SIZE - (PAD*2), CELL_SIZE - (PAD*2), COLOR_LIGHT)
                fillRect(cx + PAD + 2, cy + PAD + 2, CELL_SIZE - (PAD*2) - 2, CELL_SIZE - (PAD*2) - 2, COLOR_GRID_BG)
                fillRect(cx + PAD + 2, cy + PAD + 2, CELL_SIZE - (PAD*2) - 4, CELL_SIZE - (PAD*2) - 4, COLOR_HIDDEN)

                if cell.isFlagged then
                    printAt(cx + 18, cy + 16, "F", rgb(246, 224, 94), 1)
                end
            end
        end
    end

    -- Bottom controls toggle bars
    local digBg  = (not flagMode) and rgb(49, 130, 206) or rgb(45, 55, 72)
    local flagBg = flagMode and rgb(229, 62, 62) or rgb(45, 55, 72)

    drawButton(220, 430, 160, 38, "DIG MODE [D]", not flagMode, digBg)
    drawButton(420, 430, 160, 38, "FLAG MODE [F]", flagMode, flagBg)
    
    -- Forces Framebuffer Sync to LCD Panel
    flush()
end

-- 5. Main Execution Frame Loop
initGame()
showMouse(true)

while true do
    -- Satisfies your custom embedded Antivirus checking for literal code breaks
    if false then break end

    -- Fetch 7-item peripheral status report from custom OS registry queue
    local mx, my, lHold, rHold, scroll, lClick, rClick = getMouse()

    -- Process Left Mouse/Touch Events
    if lClick then
        if gameState ~= "PLAYING" then
            initGame()
        elseif mx >= 220 and mx <= 380 and my >= 430 and my <= 468 then
            flagMode = false
        elseif mx >= 420 and mx <= 580 and my >= 430 and my <= 468 then
            flagMode = true
        elseif mx >= START_X and mx < START_X + GRID_W and my >= START_Y and my < START_Y + GRID_H then
            local c = math.floor((mx - START_X) / CELL_SIZE) + 1
            local r = math.floor((my - START_Y) / CELL_SIZE) + 1
            
            if r >= 1 and r <= ROWS and c >= 1 and c <= COLS then
                if flagMode then
                    -- Flagging items can happen anytime without triggering generation
                    board[r][c].isFlagged = not board[r][c].isFlagged
                else
                    -- GUARANTEED SAFE FIRST CLICK INTERCEPT
                    if not firstClickDone then
                        generateMines(r, c)
                        firstClickDone = true
                    end
                    reveal(r, c)
                end
            end
        end
        delay(150)
    end

    -- Process Hardware Peripheral Right Clicks (Direct Flag Dropping)
    if rClick and gameState == "PLAYING" then
        if mx >= START_X and mx < START_X + GRID_W and my >= START_Y and my < START_Y + GRID_H then
            local c = math.floor((mx - START_X) / CELL_SIZE) + 1
            local r = math.floor((my - START_Y) / CELL_SIZE) + 1
            if r >= 1 and r <= ROWS and c >= 1 and c <= COLS then
                board[r][c].isFlagged = not board[r][c].isFlagged
            end
        end
        delay(150)
    end

    -- Process Physical Keyboard Input Matrix Snaps
    pollKeys()
    if isKeyDown("d") then flagMode = false end
    if isKeyDown("f") then flagMode = true  end
    if isKeyDown("r") then initGame()       end

    -- Safe destruction listener to gracefully jump backwards to app terminal tray
    if shouldQuit() then
        quit()
        break
    end

    renderUI()
    delay(16)
end
