-- Modern, Polished Minesweeper for ESP32-P4 OS
-- Screen resolution: 800x480

-- 1. Theme Configuration (RGB565 Colors converted via your native rgb() hook)
local COLOR_BG       = rgb(30, 30, 36)     -- Deep Slate Blue
local COLOR_GRID_BG  = rgb(21, 21, 24)     -- Darker shadow border
local COLOR_HIDDEN   = rgb(74, 85, 104)    -- Beveled unrevealed tile
local COLOR_LIGHT    = rgb(113, 128, 150)  -- Highlight edge for 3D effect
local COLOR_REVEALED = rgb(226, 232, 240)  -- Flat paper-white revealed tile
local COLOR_MINE_BG  = rgb(245, 101, 101)  -- Soft Red for exploded mine
local COLOR_TEXT     = rgb(255, 255, 255)

-- Number colors (Classic, clean palette)
local NUM_COLORS = {
    rgb(49, 130, 206),  -- 1: Blue
    rgb(56, 161, 105),  -- 2: Green
    rgb(229, 62, 62),   -- 3: Red
    rgb(116, 66, 196),  -- 4: Purple
    rgb(197, 48, 48),   -- 5: Maroon
    rgb(49, 151, 149),  -- 6: Teal
    rgb(45, 55, 72),    -- 7: Black
    rgb(113, 128, 150)  -- 8: Gray
}

-- 2. Game Sizing & Layout Setup
local COLS = 14
local ROWS = 8
local CELL_SIZE = 44
local PAD = 2

-- Center the grid on the 800x480 panel
local GRID_W = COLS * CELL_SIZE
local GRID_H = ROWS * CELL_SIZE
local START_X = math.floor((800 - GRID_W) / 2)
local START_Y = 65
local TOTAL_MINES = 18

local board = {}
local gameState = "PLAYING" -- "PLAYING", "WON", "LOST"
local flagMode = false
local mineTriggeredR, mineTriggeredC = 0, 0

-- 3. Game Logic Initialization
function initGame()
    gameState = "PLAYING"
    flagMode = false
    mineTriggeredR, mineTriggeredC = 0, 0
    board = {}

    for r = 1, ROWS do
        board[r] = {}
        for c = 1, COLS do
            board[r][c] = {
                isMine = false,
                isRevealed = false,
                isFlagged = false,
                count = 0
            }
        end
    end

    -- Seed mines randomly
    local planted = 0
    math.randomseed(millis())
    while planted < TOTAL_MINES do
        local r = math.random(1, ROWS)
        local c = math.random(1, COLS)
        if not board[r][c].isMine then
            board[r][c].isMine = true
            planted = planted + 1
        end
    end

    -- Compute neighbors
    for r = 1, ROWS do
        for c = 1, COLS do
            if not board[r][c].isMine then
                local num = 0
                for dr = -1, 1 do
                    for dc = -1, 1 do
                        local nr, nc = r + dr, c + dc
                        if nr >= 1 and nr <= ROWS and nc >= 1 and nc <= COLS then
                            if board[nr][nc].isMine then num = num + 1 end
                        end
                    end
                end
                board[r][c].count = num
            end
        end
    end
end

-- Cascade Reveal (Flood Fill)
function reveal(r, c)
    if r < 1 or r > ROWS or c < 1 or c > COLS then return end
    local cell = board[r][c]
    if cell.isRevealed or cell.isFlagged then return end

    cell.isRevealed = true

    if cell.isMine then
        gameState = "LOST"
        mineTriggeredR, mineTriggeredC = r, c
        revealAllMines()
        return
    end

    if cell.count == 0 then
        for dr = -1, 1 do
            for dc = -1, 1 do
                reveal(r + dr, c + dc)
            end
        end
    end
    checkWin()
end

function revealAllMines()
    for r = 1, ROWS do
        for c = 1, COLS do
            if board[r][c].isMine then board[r][c].isRevealed = true end
        end
    end
end

function checkWin()
    for r = 1, ROWS do
        for c = 1, COLS do
            if not board[r][c].isMine and not board[r][c].isRevealed then return end
        end
    end
    gameState = "WON"
end

-- 4. Drawing Utilities
function drawButton(x, y, w, h, label, isAct, bgCol)
    local border = isAct and rgb(236, 201, 75) or rgb(74, 85, 104)
    fillRect(x, y, w, h, border)
    fillRect(x + 2, y + 2, w - 4, h - 4, bgCol)
    drawText(x + (w / 2) - (#label * 4), y + (h / 2) - 6, label, COLOR_TEXT, 1)
end

function renderUI()
    -- Draw main background
    clear(COLOR_BG)
    
    -- Decorative Header Panel
    fillRect(0, 0, 800, 50, rgb(21, 21, 24))
    fillRect(0, 48, 800, 2, rgb(45, 55, 72))

    -- Title text status
    if gameState == "PLAYING" then
        drawText(30, 18, "MINESWEEPER", rgb(236, 201, 75), 1)
        drawText(650, 18, "MINES: " .. TOTAL_MINES, COLOR_TEXT, 1)
    elseif gameState == "WON" then
        drawText(30, 18, "VICTORY! TAP TO RESTART", rgb(72, 187, 120), 1)
    else
        drawText(30, 18, "GAME OVER! TAP TO RESTART", rgb(245, 101, 101), 1)
    end

    -- Draw outer bounding tray for the grid
    drawRect(START_X - 3, START_Y - 3, GRID_W + 6, GRID_H + 6, COLOR_GRID_BG)

    -- Render Cells
    for r = 1, ROWS do
        for c = 1, COLS do
            local cx = START_X + (c - 1) * CELL_SIZE
            local cy = START_Y + (r - 1) * CELL_SIZE
            local cell = board[r][c]

            if cell.isRevealed then
                if cell.isMine then
                    -- Triggered explosive cell versus standard background revealed mine
                    local mCol = (r == mineTriggeredR and c == mineTriggeredC) and COLOR_MINE_BG or rgb(45, 55, 72)
                    fillRect(cx + PAD, cy + PAD, CELL_SIZE - (PAD*2), CELL_SIZE - (PAD*2), mCol)
                    -- Draw cross icon '*'
                    drawText(cx + 18, cy + 16, "*", COLOR_TEXT, 1)
                else
                    -- Safe flat cell
                    fillRect(cx + PAD, cy + PAD, CELL_SIZE - (PAD*2), CELL_SIZE - (PAD*2), COLOR_REVEALED)
                    if cell.count > 0 then
                        local tc = NUM_COLORS[cell.count] or COLOR_TEXT
                        drawText(cx + 18, cy + 16, tostring(cell.count), tc, 1)
                    end
                end
            else
                -- Beautiful Beveled Tile (Light top/left edges, base center color)
                fillRect(cx + PAD, cy + PAD, CELL_SIZE - (PAD*2), CELL_SIZE - (PAD*2), COLOR_LIGHT)
                fillRect(cx + PAD + 2, cy + PAD + 2, CELL_SIZE - (PAD*2) - 2, CELL_SIZE - (PAD*2) - 2, COLOR_GRID_BG)
                fillRect(cx + PAD + 2, cy + PAD + 2, CELL_SIZE - (PAD*2) - 4, CELL_SIZE - (PAD*2) - 4, COLOR_HIDDEN)

                if cell.isFlagged then
                    -- Vibrant solid banner for flagging icon
                    drawText(cx + 18, cy + 16, "F", rgb(246, 224, 94), 1)
                end
            end
        end
    end

    -- Bottom controls: Mode toggle switch cards
    local digBg  = (not flagMode) and rgb(49, 130, 206) or rgb(45, 55, 72)
    local flagBg = flagMode and rgb(229, 62, 62) or rgb(45, 55, 72)

    drawButton(220, 430, 160, 38, "DIG MODE [D]", not flagMode, digBg)
    drawButton(420, 430, 160, 38, "FLAG MODE [F]", flagMode, flagBg)
end

-- 5. Main Framework Input Intercept Execution Loop
initGame()
showMouse(true) -- Enable default UI hardware cursor display layout

while true do
    -- Destructure all parameters returned directly by your custom `getMouse()` implementation
    local mx, my, lHold, rHold, scroll, lClick, rClick = getMouse()

    -- Process Screen Taps / Mouse clicks
    if lClick then
        if gameState ~= "PLAYING" then
            initGame()
        -- Clicked Dig Switch Card bounds
        elseif mx >= 220 and mx <= 380 and my >= 430 and my <= 468 then
            flagMode = false
        -- Clicked Flag Switch Card bounds
        elseif mx >= 420 and mx <= 580 and my >= 430 and my <= 468 then
            flagMode = true
        -- Check if user clicked inside the game board bounds area
        elseif mx >= START_X and mx < START_X + GRID_W and my >= START_Y and my < START_Y + GRID_H then
            local c = math.floor((mx - START_X) / CELL_SIZE) + 1
            local r = math.floor((my - START_Y) / CELL_SIZE) + 1
            
            if r >= 1 and r <= ROWS and c >= 1 and c <= COLS then
                if flagMode then
                    board[r][c].isFlagged = not board[r][c].isFlagged
                else
                    reveal(r, c)
                end
            end
        end
        delay(150) -- Input cool-down debounce
    end

    -- Support right-clicks natively if hardware mouse peripherals are linked to the system
    if rClick and gameState == "PLAYING" then
        if mx >= START_X and mx < START_X + GRID_W and my >= START_Y and my < START_Y + GRID_H then
            local c = math.floor((mx - START_X) / CELL_SIZE) + 1
            local r = math.floor((my - START_Y) / CELL_SIZE) + 1
            if r >= 1 and r <= ROWS and c >= 1 and c <= COLS then
                board[r][c].isFlagged = not board[r][c].isFlagged
            end
        end
        delay(150)
    end

    -- Hardware Physical Keyboard Bindings Map Checklist
    pollKeys()
    if isKeyDown("d") or isKeyDown("D") then flagMode = false end
    if isKeyDown("f") or isKeyDown("F") then flagMode = true  end
    if isKeyDown("r") or isKeyDown("R") then initGame()       end

    -- Native exit check back to OS shell interface layer handler
    if shouldQuit() then
        quit()
        break
    end

    renderUI()
    delay(16) -- ~60 FPS update cycle anchor limit protection
end
