-- ============================================================
-- PORTED MOBILE RAYCASTER (DOOM AI + SSD KEY MECHANIC)
-- Target Platform: Native OS Framework (800x480 Virtual Screen)
-- Shading style: Doom 1993 Software-Scanline Flat-Geometry
-- ============================================================

-- 1. Hardware & System Configuration Constants
local SW, SH = 800, 480
local HW, HH = 400, 240

local MAP_W = 14
local MAP_H = 14

-- Core Balancing Vectors from newfile.cxx
local MOVE_SPEED = 0.08
local STRAFE_SPEED = 0.06
local TURN_SPEED = 0.04

local SLIDE_DURATION = 30.0
local SLIDE_SPEED = 0.18
local SLIDE_FRICTION = 0.92
local SLIDE_COOLDOWN_MAX = 20
local SLIDE_DIP_MAX = 45 

-- Tactical Mil-Sim Shading Color Palette 
local COLOR_SKY         = rgb(15, 18, 22)      -- Dark tactical sky
local COLOR_FLOOR       = rgb(28, 28, 24)      -- Muddy concrete ground
local COLOR_CONCRETE_X  = rgb(95, 100, 105)    -- Concrete Wall (Facing X)
local COLOR_CONCRETE_Y  = rgb(65, 68, 72)      -- Concrete Wall (Facing Y / Shaded)
local COLOR_HELIPAD_BASE= rgb(35, 100, 45)     -- Exfiltration Zone Green
local COLOR_HELIPAD_MARK= rgb(220, 220, 220)   -- Helipad markings
local COLOR_SSD_GOLD    = rgb(212, 175, 55)    -- Secured Intel SSD Gold
local COLOR_RETICLE     = rgb(57, 255, 20)     -- Tactical NVG Green Crosshair
local COLOR_ALERT       = rgb(220, 40, 40)
local COLOR_WHITE       = rgb(255, 255, 255)
local COLOR_BLACK       = rgb(0, 0, 0)
local COLOR_HUD_BG      = rgb(20, 22, 26)
local COLOR_HUD_BORDER  = rgb(50, 55, 65)

-- 2. State Management Initialization
local worldMap = {}
local px, py = 2.5, 2.5
local playerAngle = 0.0
local FOV = 0.66

local health = 100
local ammo = 20
local level = 1

-- KEYCARD LOGIC REPLACEMENT: Tracks if player holds the SSD required for extraction
local hasSSD = false 

local bob = 0.0
local recoil = 0.0
local flash = 0

local showPopup = false
local popupText = ""
local popupTimer = 0
local showInteractPrompt = false

-- Physics & Sliding Movement States
local isSliding = false
local slideTimer = 0.0
local slideVelX, slideVelY = 0.0, 0.0
local slideCooldown = 0
local slideViewDip = 0.0
local playerVelX, playerVelY = 0.0, 0.0

-- Multi-State Object Tables
local enemies = {}
local zBuffer = {}

-- 3. Dynamic Procedural Map Generation (Preserving C++ Logic)
local function generateMap()
    math.randomseed(os.time())
    worldMap = {}
    
    -- Structure Generation
    for x = 1, MAP_W do
        worldMap[x] = {}
        for y = 1, MAP_H do
            if x == 1 or x == MAP_W or y == 1 or y == MAP_H then
                worldMap[x][y] = 1 -- Boundary Concrete Walls
            elseif (x == 7 or x == 8) and (y == 7 or y == 8) then
                worldMap[x][y] = 3 -- Centered Exfiltration Helipad Area
            elseif math.random(1, 100) > 85 then
                worldMap[x][y] = 1 
            else
                worldMap[x][y] = 0
            end
        end
    end
    
    -- Safe zone clearing around player start
    for i = 2, 4 do
        for j = 2, 4 do
            worldMap[i][j] = 0
        end
    end

    -- Plant a single Military Intel SSD Drive (Acts as the map key, ID: 2)
    local done = false
    while not done do
        local cx = math.random(4, MAP_W - 2)
        local cy = math.random(4, MAP_H - 2)
        if worldMap[cx][cy] == 0 and worldMap[cx][cy] ~= 3 then
            worldMap[cx][cy] = 2
            done = true
        end
    end
end

-- Doom-Quality Multi-State Enemy Spawner
local function spawnEnemies(count)
    enemies = {}
    local spawned = 0
    while spawned < count do
        local ex = math.random(2, MAP_W - 1)
        local ey = math.random(2, MAP_H - 1)
        if worldMap[ex][ey] == 0 and worldMap[ex][ey] ~= 3 and (ex > 4 or ey > 4) then
            table.insert(enemies, {
                x = ex + 0.5, 
                y = ey + 0.5, 
                alive = true,
                state = "PATROL",   -- AI Engine States: PATROL, AIM, FIRE, DEAD
                animTimer = 0,
                hp = 100
            })
            spawned = spawned + 1
        end
    end
end

-- 4. Collision Box Tracking Engine
local function isPassable(mx, my)
    local fX = math.floor(mx)
    local fY = math.floor(my)
    if fX < 1 or fX > MAP_W or fY < 1 or fY > MAP_H then return false end
    -- Helipad (3) and SSD (2) layers allow full traversal overlay
    return worldMap[fX][fY] == 0 or worldMap[fX][fY] == 2 or worldMap[fX][fY] == 3
end

local function tryMove(curX, curY, newX, newY)
    local margin = 0.16
    local outX = curX
    local outY = curY

    if isPassable(newX - margin, curY - margin) and
       isPassable(newX - margin, curY + margin) and
       isPassable(newX + margin, curY - margin) and
       isPassable(newX + margin, curY + margin) then
        outX = newX
    end

    if isPassable(outX - margin, newY - margin) and
       isPassable(outX - margin, newY + margin) and
       isPassable(outX + margin, newY - margin) and
       isPassable(outX + margin, newY + margin) then
        outY = newY
    end
    
    return outX, outY
end

-- 5. Mathematical 2.5D Raycaster Render Core (Clean Flat Shading)
local function drawRaycastView()
    local horizonCenter = HH + math.floor(slideViewDip)
    
    fillRect(0, 0, SW, horizonCenter, COLOR_SKY)
    fillRect(0, horizonCenter, SW, SH - horizonCenter, COLOR_FLOOR)

    local dirX, dirY = math.cos(playerAngle), math.sin(playerAngle)
    local planeX, planeY = -dirY * FOV, dirX * FOV

    local stepWidth = 4 
    
    for x = 0, SW - 1, stepWidth do
        local cameraX = 2 * x / SW - 1
        local rayDirX = dirX + planeX * cameraX
        local rayDirY = dirY + planeY * cameraX

        local mapX = math.floor(px)
        local mapY = math.floor(py)

        local deltaDistX = (rayDirX == 0) and 1e30 or math.abs(1 / rayDirX)
        local deltaDistY = (rayDirY == 0) and 1e30 or math.abs(1 / rayDirY)
        
        local sideDistX, sideDistY = 0, 0
        local stepX, stepY = 0, 0
        local hit = 0
        local side = 0

        if rayDirX < 0 then
            stepX = -1; sideDistX = (px - mapX) * deltaDistX
        else
            stepX = 1; sideDistX = (mapX + 1.0 - px) * deltaDistX
        end
        if rayDirY < 0 then
            stepY = -1; sideDistY = (py - mapY) * deltaDistY
        else
            stepY = 1; sideDistY = (mapY + 1.0 - py) * deltaDistY
        end

        while hit == 0 do
            if sideDistX < sideDistY then
                sideDistX = sideDistX + deltaDistX; mapX = mapX + stepX; side = 0
            else
                sideDistY = sideDistY + deltaDistY; mapY = mapY + stepY; side = 1
            end
            if mapX >= 1 and mapX <= MAP_W and mapY >= 1 and mapY <= MAP_H then
                if worldMap[mapX][mapY] > 0 then hit = worldMap[mapX][mapY] end
            else
                break
            end
        end

        local perpWallDist = 0
        if side == 0 then perpWallDist = (sideDistX - deltaDistX) else perpWallDist = (sideDistY - deltaDistY) end
        if perpWallDist < 0.05 then perpWallDist = 0.05 end

        for i = 0, stepWidth - 1 do
            if x + i < SW then zBuffer[x + i] = perpWallDist end
        end

        local lineHeight = math.floor(SH / perpWallDist)
        local drawStart = math.floor(-lineHeight / 2 + horizonCenter)
        local drawEnd = drawStart + lineHeight

        local vStart = (drawStart < 0) and 0 or drawStart
        local vEnd = (drawEnd > SH) and SH or drawEnd

        -- Material Projection Routing
        if hit == 1 then -- Flat-Shaded Mil-Sim Concrete Walls
            local wallColor = (side == 0) and COLOR_CONCRETE_X or COLOR_CONCRETE_Y
            fillRect(x, vStart, stepWidth, vEnd - vStart, wallColor)
        elseif hit == 3 then -- Helipad Perimeter Projection Plane
            fillRect(x, vStart, stepWidth, vEnd - vStart, COLOR_HELIPAD_BASE)
            if lineHeight > 45 and (x % 32 < 6) then
                fillRect(x, vStart + math.floor(lineHeight * 0.15), stepWidth, math.floor(lineHeight * 0.7), COLOR_HELIPAD_MARK)
            end
        end
    end
end

-- 6. Doom (1993) Style Multi-State Infantry Sprite Billboarding
local function drawEnemies3D()
    local gameTime = millis()
    local horizonCenter = HH + math.floor(slideViewDip)
    local dirX, dirY = math.cos(playerAngle), math.sin(playerAngle)
    local planeX, planeY = -dirY * FOV, dirX * FOV

    for _, e in ipairs(enemies) do
        local spriteX = e.x - px
        local spriteY = e.y - py

        local invDet = 1.0 / (planeX * dirY - dirX * planeY)
        local transformX = invDet * (dirY * spriteX - dirX * spriteY)
        local transformY = invDet * (-planeY * spriteX + planeX * spriteY)

        if transformY > 0.1 then
            local spriteScreenX = math.floor((SW / 2) * (1 + transformX / transformY))
            local spriteHeight = math.abs(math.floor(SH / transformY))
            local spriteWidth = math.abs(math.floor(SH / transformY))

            local drawYStart = math.floor(-spriteHeight / 2 + horizonCenter)

            if spriteScreenX >= 0 and spriteScreenX < SW then
                if zBuffer[spriteScreenX] and zBuffer[spriteScreenX] > transformY then
                    
                    local sw = math.floor(spriteWidth * 0.38)
                    if sw < 4 then sw = 4 end
                    local sh = math.floor(spriteHeight * 0.85)

                    -- Tactical Sprite Component Color Profiles
                    local camoPants   = rgb(55, 70, 45)     -- Woodland fatigue tone
                    local armorVest   = rgb(45, 48, 52)     -- Combat plate carrier
                    local skinTone    = rgb(225, 165, 135)
                    local weaponMetal = rgb(18, 18, 20)

                    -- Render Doom Post-Mortem Frame Instantly if state is DEAD
                    if e.state == "DEAD" then
                        local corpseW = math.floor(sw * 1.4)
                        local corpseH = math.floor(sh * 0.22)
                        local deadY = drawYStart + sh - corpseH
                        fillRect(spriteScreenX - math.floor(corpseW/2), deadY, corpseW, corpseH, camoPants)
                        fillRect(spriteScreenX - math.floor(corpseW/4), deadY - 2, math.floor(corpseW/2), corpseH, armorVest)
                    else
                        local legBob = 0
                        local weaponIsRaised = false

                        if e.state == "PATROL" then
                            legBob = math.sin(gameTime * 0.012) * (spriteHeight * 0.02)
                        elseif e.state == "AIM" or e.state == "FIRE" then
                            weaponIsRaised = true
                        end

                        -- Legs Layout
                        fillRect(spriteScreenX - math.floor(sw * 0.32), drawYStart + math.floor(sh * 0.76) + math.floor(legBob), math.floor(sw * 0.24), math.floor(sh * 0.24), camoPants)
                        fillRect(spriteScreenX + math.floor(sw * 0.08), drawYStart + math.floor(sh * 0.76) - math.floor(legBob), math.floor(sw * 0.24), math.floor(sh * 0.24), camoPants)
                        
                        -- Torso Core
                        fillRect(spriteScreenX - math.floor(sw / 2), drawYStart + math.floor(sh * 0.25), sw, math.floor(sh * 0.55), camoPants)
                        fillRect(spriteScreenX - math.floor(sw * 0.45), drawYStart + math.floor(sh * 0.26), math.floor(sw * 0.9), math.floor(sh * 0.42), armorVest)

                        -- Weapons Alignment Matrix (Doom Style Processing States)
                        if weaponIsRaised then
                            local gunW = math.floor(sw * 0.24); if gunW < 4 then gunW = 4 end
                            local gunH = math.floor(sh * 0.42)
                            fillRect(spriteScreenX - math.floor(gunW/2), drawYStart + math.floor(sh * 0.35), gunW, gunH, weaponMetal)
                            
                            if e.state == "FIRE" then -- Flash engine pipeline injection
                                fillRect(spriteScreenX - math.floor(gunW), drawYStart + math.floor(sh * 0.68), gunW * 2, 6, COLOR_SSD_GOLD)
                            end
                        else
                            -- Relaxed low-ready patrol stance weapon geometry
                            fillRect(spriteScreenX - math.floor(sw * 0.15), drawYStart + math.floor(sh * 0.52), math.floor(sw * 0.6), 5, weaponMetal)
                        end

                        -- Head Unit 
                        local headSize = math.floor(sw * 0.38)
                        if headSize < 3 then headSize = 3 end
                        fillRect(spriteScreenX - math.floor(headSize/2), drawYStart + math.floor(sh * 0.06), headSize, headSize, skinTone)
                        fillRect(spriteScreenX - math.floor(headSize/2), drawYStart + 2, headSize, math.floor(headSize * 0.5), armorVest) -- Combat Helmet Brim
                    end
                end
            end
        end
    end
end

-- 7. Military Encrypted SSD Drive Key Object System (Hidden when grabbed)
local function drawSSDObjects3D()
    if hasSSD then return end -- Key grabbed, cease sprite evaluation loops

    local horizonCenter = HH + math.floor(slideViewDip)
    local dirX, dirY = math.cos(playerAngle), math.sin(playerAngle)
    local planeX, planeY = -dirY * FOV, dirX * FOV

    for x = 1, MAP_W do
        for y = 1, MAP_H do
            if worldMap[x][y] == 2 then 
                local spriteX = (x + 0.5) - px
                local spriteY = (y + 0.5) - py

                local invDet = 1.0 / (planeX * dirY - dirX * planeY)
                local transformX = invDet * (dirY * spriteX - dirX * spriteY)
                local transformY = invDet * (-planeY * spriteX + planeX * spriteY)

                if transformY > 0.1 then
                    local sScreenX = math.floor((SW / 2) * (1 + transformX / transformY))
                    local sHeight = math.abs(math.floor(SH / transformY))

                    if sScreenX >= 0 and sScreenX < SW and zBuffer[sScreenX] > transformY then
                        local ssdW = math.floor(sHeight * 0.16)
                        local ssdH = math.floor(sHeight * 0.22)
                        local floatBob = math.sin(millis() * 0.005) * 6
                        local ssdY = math.floor(-sHeight / 2 + horizonCenter) + math.floor(sHeight * 0.5) + math.floor(floatBob)

                        if ssdW > 2 and ssdH > 2 then
                            -- Main Housing Shell
                            fillRect(sScreenX - math.floor(ssdW/2), ssdY, ssdW, ssdH, rgb(35, 35, 40))
                            -- Exposed Gold Bus Contacts
                            fillRect(sScreenX - math.floor(ssdW/4), ssdY + 3, math.floor(ssdW/2), 3, COLOR_SSD_GOLD)
                            -- Outer thermal label sticker
                            fillRect(sScreenX - math.floor(ssdW/3), ssdY + math.floor(ssdH * 0.4), math.floor(ssdW * 0.6), math.floor(ssdH * 0.35), rgb(20, 50, 100))
                        end
                    end
                end
            end
        end
    end
end

-- 8. First-Person Tactical Service Carbine (Updated Overlay View)
local function drawHUDWeapon()
    local bx, by = 0, 0
    local isMoving = (math.abs(playerVelX) > 0.001 or math.abs(playerVelY) > 0.001)

    if isMoving and not isSliding then
        bob = bob + 0.3
        bx = math.sin(bob) * 8
        by = math.abs(math.cos(bob)) * 5
    elseif isSliding then
        bob = bob + 0.5
        bx = math.sin(bob) * 3
        by = 0
    end

    recoil = recoil * 0.8
    if flash > 0 then flash = flash - 1 end

    local cx = HW + math.floor(bx)
    local cy = HH - 30 + math.floor(by) - math.floor(recoil * 3) + math.floor(slideViewDip)

    -- Service Carbine Weapon Composite Layers
    fillRect(cx - 75, cy + 145, 150, 45, rgb(30, 32, 35))     -- Gun Body Receiver
    fillRect(cx - 40, cy + 90, 80, 55, rgb(44, 48, 54))       -- Optical Mount Interface
    fillRect(cx - 10, cy + 35, 20, 55, rgb(20, 22, 25))       -- Muzzle Barrel Extender

    -- Holographic Red Dot Optics
    fillRect(cx - 22, cy + 55, 44, 35, rgb(58, 62, 70))
    rect(cx - 18, cy + 60, 36, 25, COLOR_BLACK)
    if not isSliding then
        fillRect(cx - 1, cy + 71, 3, 3, COLOR_ALERT)         -- Red Dot center reticle
    end

    -- Muzzle Flash Event Handling
    if flash > 0 then
        fillTriangle(cx, cy + 10, cx - 22, cy + 35, cx + 22, cy + 35, COLOR_SSD_GOLD)
        fillRect(cx - 8, cy + 22, 16, 12, COLOR_WHITE)
    end
end

-- 9. Heads Up Data Tactical Instrument Cockpit Overlay
local function drawInterfaceOverlay()
    local nx, ny = HW - 180, SH - 85
    fillRect(nx, ny, 360, 80, COLOR_HUD_BG)
    rect(nx, ny, 360, 80, COLOR_HUD_BORDER)

    printAt(nx + 15, ny + 15, "AMMO: " .. ammo .. " / MAG", COLOR_WHITE, 1)
    printAt(nx + 15, ny + 45, "VITALS: " .. health .. "%", health > 30 and COLOR_RETICLE or COLOR_ALERT, 1)
    printAt(nx + 185, ny + 45, "SECURITY TIER: " .. level, COLOR_WHITE, 1)

    -- KEY STATUS HUD INTERFACE DISPLAY: Swaps color based on key card possession
    if hasSSD then
        printAt(nx + 185, ny + 15, "INTEL SSD: SECURED", COLOR_RETICLE, 1)
    else
        printAt(nx + 185, ny + 15, "INTEL SSD: MISSING", COLOR_ALERT, 1)
    end

    if showInteractPrompt and not showPopup then
        printAt(HW - 110, HH - 40, "PRESS [E] TO COLLECT INTEL SSD", COLOR_WHITE, 1)
    end

    -- Helipad Key Check HUD Notification Tracker
    local currentR, currentC = math.floor(py), math.floor(px)
    if currentR >= 1 and currentR <= MAP_W and currentC >= 1 and currentC <= MAP_W and worldMap[currentC][currentR] == 3 then
        if hasSSD then
            printAt(HW - 120, HH + 40, "EXFIL ACTIVE: TRANSMITTING ENCRYPTED DRIVE...", COLOR_RETICLE, 1)
        else
            printAt(HW - 120, HH + 40, "EXFIL LOCKED: RETRIEVE INTEL SSD FIRST!", COLOR_ALERT, 1)
        end
    end

    if showPopup then
        fillRect(HW - 150, HH - 25, 300, 45, COLOR_BLACK)
        rect(HW - 150, HH - 25, 300, 45, COLOR_RETICLE)
        printAt(HW - 115, HH - 10, popupText, COLOR_WHITE, 1)
        popupTimer = popupTimer - 1
        if popupTimer <= 0 then showPopup = false end
    end

    -- Crosshairs Alignment
    local crossY = HH + math.floor(slideViewDip)
    fillRect(HW - 1, crossY - 8, 2, 16, COLOR_RETICLE)
    fillRect(HW - 8, crossY - 1, 16, 2, COLOR_RETICLE)
end

local function isEnemyInCrosshair(e)
    local angleToEnemy = math.atan2(e.y - py, e.x - px)
    local diff = angleToEnemy - playerAngle
    while diff < -math.pi do diff = diff + (math.pi * 2) end
    while diff > math.pi do diff = diff - (math.pi * 2) end
    local dist = math.sqrt((e.x - px)^2 + (e.y - py)^2)
    local tolerance = 0.25 / (dist + 0.5)
    return math.abs(diff) < tolerance, dist
end

-- 10. Initialization Sequence
local function initGame()
    px, py = 2.5, 2.5
    playerAngle = 0.0
    health = 100
    ammo = 20
    level = 1
    hasSSD = false -- Reset keycard tracking flag status
    isSliding = false
    slideTimer = 0.0
    slideCooldown = 0
    slideViewDip = 0.0
    generateMap()
    spawnEnemies(3)
end

initGame()
showMouse(false)

-- ============================================================
-- 11. Core Engine Execution Frame Runtime Loop
-- ============================================================
while true do
    pollKeys()
    local mx, my, lHold, rHold, scroll, lClick, rClick = getMouse()

    -- Process Camera Mouse Aiming Look Vectors
    if mx > 0 and mx < SW then
        local deltaX = mx - HW
        if math.abs(deltaX) > 1 then
            playerAngle = playerAngle + (deltaX * 0.004)
            setMousePos(HW, HH)
        end
    end

    -- Process Projectile Weapon Discharges
    if lClick and ammo > 0 and flash == 0 then
        recoil = 25
        flash = 3
        ammo = ammo - 1
        
        for _, e in ipairs(enemies) do
            if e.alive and e.state ~= "DEAD" then
                local isHit, hitDist = isEnemyInCrosshair(e)
                if isHit and hitDist < 14.0 then
                    e.hp = e.hp - math.random(40, 60)
                    e.state = "AIM" -- Aggronizes enemy tracking onto threat source location
                    if e.hp <= 0 then
                        e.alive = false
                        e.state = "DEAD"
                    end
                end
            end
        end
    end

    -- Physics Force Computation
    local moveX, moveY = 0.0, 0.0
    local ms = MOVE_SPEED
    local ss = STRAFE_SPEED

    if isKeyDown("w") or isKeyDown("up") then
        moveX = moveX + math.cos(playerAngle) * ms
        moveY = moveY + math.sin(playerAngle) * ms
    end
    if isKeyDown("s") or isKeyDown("down") then
        moveX = moveX - math.cos(playerAngle) * ms
        moveY = moveY - math.sin(playerAngle) * ms
    end
    if isKeyDown("a") then
        moveX = moveX + (-math.sin(playerAngle)) * ss
        moveY = moveY + math.cos(playerAngle) * ss
    end
    if isKeyDown("d") then
        moveX = moveX - (-math.sin(playerAngle)) * ss
        moveY = moveY - math.cos(playerAngle) * ss
    end

    if math.abs(moveX) > 0.001 or math.abs(moveY) > 0.001 then
        playerVelX, playerVelY = moveX, moveY
    end

    -- Ground Sliding Controls
    if isKeyDown("c") and not isSliding and slideCooldown <= 0 then
        local velMag = math.sqrt(playerVelX^2 + playerVelY^2)
        if velMag > 0.01 then
            isSliding = true
            slideTimer = SLIDE_DURATION
            slideVelX = (playerVelX / velMag) * SLIDE_SPEED
            slideVelY = (playerVelY / velMag) * SLIDE_SPEED
        end
    end

    if isSliding and isKeyDown("space") then
        isSliding = false
        slideTimer = 0
        slideCooldown = SLIDE_COOLDOWN_MAX
        slideVelX, slideVelY = 0.0, 0.0
        slideViewDip = 0.0
    end

    if isSliding then
        slideTimer = slideTimer - 1.0
        px, py = tryMove(px, py, px + slideVelX, py + slideVelY)
        slideVelX = slideVelX * SLIDE_FRICTION
        slideVelY = slideVelY * SLIDE_FRICTION

        local slideProgress = 1.0 - (slideTimer / SLIDE_DURATION)
        if slideProgress < 0.2 then
            slideViewDip = slideProgress * 5.0 * SLIP_DIP_MAX
        elseif slideProgress > 0.7 then
            slideViewDip = (1.0 - slideProgress) * (1.0 / 0.3) * SLIDE_DIP_MAX
        else
            slideViewDip = SLIDE_DIP_MAX
        end

        moveX, moveY = 0.0, 0.0
        if slideTimer <= 0 or math.sqrt(slideVelX^2 + slideVelY^2) < 0.002 then
            isSliding = false
            slideCooldown = SLIDE_COOLDOWN_MAX
            slideViewDip = 0.0
        end
    else
        slideViewDip = slideViewDip * 0.7
        if slideCooldown > 0 then slideCooldown = slideCooldown - 1 end
    end

    if not isSliding and (math.abs(moveX) > 0.001 or math.abs(moveY) > 0.001) then
        px, py = tryMove(px, py, px + moveX, py + moveY)
    end

    -- Doom AI Logic Engine Routing Frame Loop
    local anyAlive = false
    for _, e in ipairs(enemies) do
        if e.state ~= "DEAD" then
            anyAlive = true
            local distSq = (px - e.x)^2 + (py - e.y)^2
            local dist = math.sqrt(distSq)

            if e.state == "PATROL" then
                if dist < 8.0 then
                    e.state = "AIM"
                    e.animTimer = math.random(15, 32)
                else
                    local targetAngle = math.atan2(py - e.y, px - e.x)
                    e.x, e.y = tryMove(e.x, e.y, e.x + math.cos(targetAngle) * 0.02, e.y + math.sin(targetAngle) * 0.02)
                end
            elseif e.state == "AIM" then
                e.animTimer = e.animTimer - 1
                if e.animTimer <= 0 then
                    e.state = "FIRE"
                    e.animTimer = 6 
                end
            elseif e.state == "FIRE" then
                e.animTimer = e.animTimer - 1
                if e.animTimer == 4 and dist < 10.0 then 
                    health = health - math.random(5, 12)
                    if health <= 0 then initGame() break end
                end
                if e.animTimer <= 0 then
                    e.state = "PATROL"
                end
            end
        end
    end

    -- Scanning Adjacent Proximities for Intel SSD Items
    showInteractPrompt = false
    local lootX, lootY = -1, -1
    local pmx, pmy = math.floor(px), math.floor(py)

    for ix = -1, 1 do
        local checkX = pmx + ix
        if checkX >= 1 and checkX <= MAP_W then
            for iy = -1, 1 do
                local checkY = pmy + iy
                if checkY >= 1 and checkY <= MAP_H then
                    -- Only look for target tile if player doesn't hold the keycard already
                    if worldMap[checkX][checkY] == 2 and not hasSSD then
                        local cdist = (px - (checkX + 0.5))^2 + (py - (checkY + 0.5))^2
                        if cdist < 1.96 then
                            showInteractPrompt = true
                            lootX, lootY = checkX, checkY
                        end
                    end
                end
            end
        end
    end

    -- Process Keycard SSD Collection Hook
    if isKeyDown("e") and showInteractPrompt and not showPopup then
        hasSSD = true -- Security token secured!
        worldMap[lootX][lootY] = 0
        popupText = "ENCRYPTED SSD KEY RETRIEVED! EXFIL UNLOCKED"
        showPopup = true
        popupTimer = 75
        ammo = ammo + 10 
    end

    -- Exfiltration Helipad Exit Trigger Check (Requires SSD to pass, matches original layout end logic)
    local curTileR = math.floor(py)
    local curTileC = math.floor(px)
    if curTileR >= 1 and curTileR <= MAP_W and curTileC >= 1 and curTileC <= MAP_W then
        -- LEVEL PROGRESSION TRIGGER CONDITIONS: 
        -- 1. Must stand inside Helipad tiles (3)
        -- 2. Must hold the SSD drive (hasSSD == true)
        -- 3. All threatening combat entities must be neutralized
        if worldMap[curTileC][curTileR] == 3 and hasSSD and not anyAlive then
            level = level + 1
            hasSSD = false -- Wipe keycard tracking container flag for next procedural map seed
            isSliding = false
            slideTimer = 0.0
            slideCooldown = 0
            slideVelX, slideVelY = 0.0, 0.0
            slideViewDip = 0.0
            
            popupText = "MISSION OBJECTIVE COMPLETE! SEEDING NEXT TIER..."
            showPopup = true
            popupTimer = 75
            
            generateMap()
            spawnEnemies(2 + level)
            px, py = 2.5, 2.5
            playerAngle = 0.0
        end
    end

    -- ============================================================
    -- Viewport Graphics Merging Composition Construction
    -- ============================================================
    drawRaycastView()
    drawSSDObjects3D()
    drawEnemies3D()
    drawHUDWeapon()
    drawInterfaceOverlay()

    -- Process Crosshatch Critical Blood Overlays
    if health < 50 then
        local hatchStep = math.floor(health / 10) + 1
        if hatchStep < 2 then hatchStep = 2 end
        for y = 0, SH - 1, hatchStep do
            fillRect(0, y, SW, 1, rgb(150, 0, 0))
        end
    end

    flush()
    if shouldQuit() then quit(); break end
    delay(16)
end
