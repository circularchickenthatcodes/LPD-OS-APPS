-- Operation: Spectre Strike (Director's Cut Max) - 3D Mil-Sim Engine
-- Screen resolution: SCREEN_W (800) x SCREEN_H (480)

-- 1. Color Palette Definitions
local COLOR_SKY      = rgb(25, 28, 32)      
local COLOR_FLOOR    = rgb(15, 16, 20)      
local COLOR_HUD_BG   = rgb(8, 10, 12)       
local COLOR_RETICLE  = rgb(57, 255, 20)     
local COLOR_ALERT    = rgb(239, 68, 68)     
local COLOR_DOOR     = rgb(120, 80, 20)      

-- 2. Tactical Map Grid Layout (16x16 Dimensions)
local MAP_WIDTH  = 16
local MAP_HEIGHT = 16

local worldMap = {
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1},
    {1,0,1,0,4,0,1,1,1,1,0,4,0,1,0,1},
    {1,0,1,0,0,0,0,0,0,1,0,0,0,1,0,1},
    {1,0,1,1,1,1,1,0,0,1,1,1,1,1,0,1},
    {1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1},
    {1,1,1,0,1,0,1,0,0,1,0,1,0,1,1,1},
    {1,0,0,0,1,0,0,0,0,0,0,1,0,0,0,1},
    {1,0,1,0,1,1,1,4,4,1,1,1,0,1,0,1},
    {1,0,1,0,0,0,1,2,2,1,0,0,0,1,0,1},
    {1,0,1,1,1,0,1,0,0,1,0,1,1,1,0,1},
    {1,0,0,0,1,0,1,1,1,1,0,1,0,0,0,1},
    {1,1,0,0,1,0,0,0,0,0,0,1,0,0,1,1},
    {1,0,0,0,1,1,1,1,1,1,1,1,0,0,0,1},
    {1,0,3,0,0,0,0,0,0,0,0,0,0,0,0,1},
    {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
}

-- 3. Player Movement, Loadout & Advanced Animation States
local playerX, playerY = 2.5, 2.5
local playerAngle = 0.0
local FOV = 0.66

local camHeightOffset = 0      
local strafeSwayOffset = 0    
local weaponTiltAngle = 0     
local slideTimer = 0          
local slideMaxTime = 20       
local slideVelX = 0           
local slideVelY = 0           
local isSliding = false

local ammoMag = 30
local maxMag  = 30
local reserves = 120
local isReloading = false
local reloadTimer = 0
local weaponKick = 0
local muzzleFlash = 0
local health = 100

local zBuffer = {}

local currentObjective = 1
local objectiveText = {
    [1] = "BREACH INTEL SECTOR: USE [E] TO OPEN BLAST DOORS",
    [2] = "ACCESS SERVER STACK: STAND ON TERMINAL BLUE CELL",
    [3] = "Intel Downloaded! RUN TO EXFILTRATION HELIPAD [GREEN]"
}

local enemies = {
    { x = 8.5,  y = 4.5,  hp = 100, maxHp = 100, active = true, state = "PATROL", tgtX = 8.5,  tgtY = 4.5,  cooldown = 0, strafeDir = 1 },
    { x = 13.5, y = 7.5,  hp = 100, maxHp = 100, active = true, state = "PATROL", tgtX = 13.5, tgtY = 7.5,  cooldown = 0, strafeDir = -1 },
    { x = 8.5,  y = 13.5, hp = 100, maxHp = 100, active = true, state = "PATROL", tgtX = 8.5,  tgtY = 13.5, cooldown = 0, strafeDir = 1 }
}

local function isTileSolid(gx, gy)
    local r = math.floor(gy)
    local c = math.floor(gx)
    if r < 1 or r > MAP_HEIGHT or c < 1 or c > MAP_WIDTH then return true end
    return worldMap[r][c] == 1 or worldMap[r][c] == 4
end

---------------------------------------------------------------
-- 4. STATIC TEXTURE CACHE SYSTEM (FPS BOOSTER)
---------------------------------------------------------------
local TEX_SIZE = 64
local textureCache = { [1] = {}, [2] = {}, [3] = {}, [4] = {} }

local function precalculateTextures()
    for x = 0, TEX_SIZE - 1 do
        textureCache[1][x] = {}
        textureCache[2][x] = {}
        textureCache[3][x] = {}
        textureCache[4][x] = {}
        
        for y = 0, TEX_SIZE - 1 do
            -- Texture 1: Concrete Bunker Wall
            if x % 32 < 2 or y % 16 < 2 then
                textureCache[1][x][y] = rgb(45, 48, 52)
            else
                local noise = ((x * 7 + y * 13) % 11) * 2.5
                local r = 110 - noise
                local g = 115 - noise
                local b = 120 - noise
                if y > 45 then r, g, b = r - 15, g - 12, b - 10 end
                textureCache[1][x][y] = rgb(r, g, b)
            end

            -- Texture 4: Blast Door
            if y < 12 or y > 52 then
                if (x + y) % 16 < 8 then textureCache[4][x][y] = rgb(210, 160, 20)
                else textureCache[4][x][y] = rgb(25, 25, 28) end
            else
                if y % 14 < 2 then textureCache[4][x][y] = rgb(40, 30, 15)
                else
                    if x > 26 and x < 38 then textureCache[4][x][y] = rgb(75, 75, 80)
                    else textureCache[4][x][y] = rgb(130, 95, 35) end
                end
            end

            -- Texture 2: Server Mainframe
            if x % 16 < 3 then
                textureCache[2][x][y] = rgb(15, 15, 18)
            else
                textureCache[2][x][y] = rgb(25, 30, 40)
            end

            -- Texture 3: Exfil Zone Pad
            if x < 4 or x > 60 or y < 4 or y > 60 then
                textureCache[3][x][y] = rgb(30, 220, 60)
            else
                textureCache[3][x][y] = rgb(45, 55, 48)
            end
        end
    end
end

precalculateTextures()

---------------------------------------------------------------
-- 5. HIGH-SPEED RAYCAST VIEW ENGINE
---------------------------------------------------------------
function drawRaycastView()
    fillRect(0, 0, SCREEN_W, 200, COLOR_SKY)
    fillRect(0, 200, SCREEN_W, 200, COLOR_FLOOR)

    local dirX, dirY = math.cos(playerAngle), math.sin(playerAngle)
    local planeX, planeY = -dirY * FOV, dirX * FOV
    local horizonCenter = 200 + camHeightOffset
    local gameTime = millis()

    local stepWidth = 8
    for x = 0, SCREEN_W - 1, stepWidth do
        local cameraX = 2 * x / SCREEN_W - 1
        local rayDirX = dirX + planeX * cameraX
        local rayDirY = dirY + planeY * cameraX

        local mapX = math.floor(playerX)
        local mapY = math.floor(playerY)

        local sideDistX, sideDistY = 0, 0
        local deltaDistX = (rayDirX == 0) and 1e30 or math.abs(1 / rayDirX)
        local deltaDistY = (rayDirY == 0) and 1e30 or math.abs(1 / rayDirY)
        local perpWallDist = 0

        local stepX, stepY = 0, 0
        local hit = 0
        local side = 0

        if rayDirX < 0 then stepX = -1; sideDistX = (playerX - mapX) * deltaDistX
        else stepX = 1; sideDistX = (mapX + 1.0 - playerX) * deltaDistX end
        if rayDirY < 0 then stepY = -1; sideDistY = (playerY - mapY) * deltaDistY
        else stepY = 1; sideDistY = (mapY + 1.0 - playerY) * deltaDistY end

        while hit == 0 do
            if sideDistX < sideDistY then
                sideDistX = sideDistX + deltaDistX; mapX = mapX + stepX; side = 0
            else
                sideDistY = sideDistY + deltaDistY; mapY = mapY + stepY; side = 1
            end
            if mapX >= 1 and mapX <= MAP_WIDTH and mapY >= 1 and mapY <= MAP_HEIGHT then
                if worldMap[mapY][mapX] > 0 then hit = worldMap[mapY][mapX] end
            else break end
        end

        if side == 0 then perpWallDist = (sideDistX - deltaDistX) else perpWallDist = (sideDistY - deltaDistY) end
        if perpWallDist < 0.1 then perpWallDist = 0.1 end

        for i = 0, stepWidth - 1 do
            if x + i < SCREEN_W then zBuffer[x + i] = perpWallDist end
        end

        local lineHeight = math.floor(400 / perpWallDist)
        local drawStart = math.floor(-lineHeight / 2 + horizonCenter)
        local drawEnd   = drawStart + lineHeight

        local vStart = drawStart; if vStart < 0 then vStart = 0 end
        local vEnd = drawEnd; if vEnd > 400 then vEnd = 400 end

        local wallX = 0
        if side == 0 then wallX = playerY + perpWallDist * rayDirY else wallX = playerX + perpWallDist * rayDirX end
        wallX = wallX - math.floor(wallX)
        local texX = math.floor(wallX * (TEX_SIZE - 1))

        local currentY = vStart
        while currentY < vEnd do
            local texY = math.floor(((currentY - drawStart) * TEX_SIZE) / lineHeight)
            if texY < 0 then texY = 0 elseif texY > (TEX_SIZE - 1) then texY = (TEX_SIZE - 1) end
            
            local baseColor = textureCache[hit][texX][texY]
            
            if hit == 2 and (texY % 8 == 0 and texX % 4 == 0) then
                if (gameTime + texY * 10) % 800 > 400 then baseColor = rgb(0, 140, 255)
                else baseColor = rgb(0, 230, 120) end
            end

            local spanHeight = 1
            while (currentY + spanHeight) < vEnd do
                local nextTexY = math.floor((((currentY + spanHeight) - drawStart) * TEX_SIZE) / lineHeight)
                if nextTexY < 0 then nextTexY = 0 elseif nextTexY > (TEX_SIZE - 1) then nextTexY = (TEX_SIZE - 1) end
                
                if nextTexY == texY then
                    spanHeight = spanHeight + 1
                else
                    break
                end
            end

            fillRect(x, currentY, stepWidth, spanHeight, baseColor)
            currentY = currentY + spanHeight
        end
    end
end

-- 6. Animated Distance-Scaled Tactical Soldier Layer
function draw3DEntities()
    local dirX, dirY = math.cos(playerAngle), math.sin(playerAngle)
    local planeX, planeY = -dirY * FOV, dirX * FOV
    local gameTime = millis()
    local horizonCenter = 200 + camHeightOffset

    for i, e in ipairs(enemies) do
        if e.active then
            local spriteX = e.x - playerX; local spriteY = e.y - playerY

            local invDet = 1.0 / (planeX * dirY - dirX * planeY)
            local transformX = invDet * (dirY * spriteX - dirX * spriteY)
            local transformY = invDet * (-planeY * spriteX + planeX * spriteY)

            if transformY > 0.2 then
                local spriteScreenX = math.floor((SCREEN_W / 2) * (1 + transformX / transformY))
                local spriteHeight = math.abs(math.floor(400 / transformY))
                local spriteWidth = math.abs(math.floor(400 / transformY))

                local drawYStart = math.floor(-spriteHeight / 2 + horizonCenter)

                if spriteScreenX >= 0 and spriteScreenX < SCREEN_W then
                    if zBuffer[spriteScreenX] and zBuffer[spriteScreenX] > transformY then
                        
                        local w = math.floor(spriteWidth * 0.35)
                        if w < 4 then w = 4 end
                        local midX = spriteScreenX
                        
                        local camoBase  = rgb(59, 68, 54)   
                        local camoSpot  = rgb(38, 43, 35)   
                        local armorVest = rgb(45, 48, 44)   
                        local helmetCol = rgb(70, 78, 65)   
                        local nvgCol    = (e.state == "RETREAT" or e.state == "RECOVER") and rgb(0, 150, 255) or rgb(0, 255, 68) 
                        local weaponCol = rgb(20, 20, 22)   

                        local isMoving = (e.state == "COMBAT" or e.state == "PATROL" or e.state == "RETREAT")
                        local speedMult = (e.state == "RETREAT") and 0.024 or 0.012
                        
                        local walkCycle = (gameTime * speedMult) + (i * 45)
                        local bobCycle  = (gameTime * 0.005) + (i * 30)
                        
                        local idleBobY = math.floor(math.sin(bobCycle) * (spriteHeight * 0.015))
                        if e.state == "COMBAT" or e.state == "RETREAT" then
                            idleBobY = math.floor(math.sin(gameTime * 0.018) * (spriteHeight * 0.02))
                        end
                        local legSwing = isMoving and (math.sin(walkCycle) * (w * 0.22)) or 0

                        local bodyTop = drawYStart + math.floor(spriteHeight * 0.3) + idleBobY
                        local bodyH   = math.floor(spriteHeight * 0.45)
                        local legTop  = bodyTop + bodyH
                        local legH    = math.floor(spriteHeight * 0.15)
                        local legW    = math.floor(w * 0.28)

                        fillRect(midX - math.floor(w * 0.3) + math.floor(legSwing), legTop, legW, legH, camoBase)
                        fillRect(midX + math.floor(w * 0.05) - math.floor(legSwing), legTop, legW, legH, camoBase)

                        fillRect(midX - math.floor(w / 2), bodyTop, w, bodyH, camoBase)
                        local vestW = math.floor(w * 0.85); local vestH = math.floor(bodyH * 0.7)
                        fillRect(midX - math.floor(vestW / 2), bodyTop + math.floor(bodyH * 0.08), vestW, vestH, armorVest)

                        if spriteHeight > 30 then
                            local gunY = bodyTop + math.floor(bodyH * 0.5)
                            local gunW = math.floor(w * 0.7); local gunH = math.floor(spriteHeight * 0.035)
                            if gunH < 2 then gunH = 2 end
                            local gunX = midX - math.floor(gunW / 2)
                            
                            if e.state == "COMBAT" then
                                fillRect(gunX, gunY, gunW, gunH, weaponCol)
                            else
                                line(midX - math.floor(w*0.3), gunY + gunH + 10, midX + math.floor(w*0.3), gunY - gunH + 10, weaponCol)
                            end
                        end

                        local headRadius = math.floor(w * 0.26)
                        if headRadius < 2 then headRadius = 2 end
                        local headY = drawYStart + math.floor(spriteHeight * 0.22) + idleBobY
                        circle(midX, headY, headRadius, rgb(25, 25, 27), true)
                        circle(midX, headY - math.floor(headRadius * 0.15), headRadius + 1, helmetCol, true)

                        if math.abs(midX - 400) < 45 then
                            rect(midX - math.floor(w/2) - 4, drawYStart, w + 8, spriteHeight, COLOR_RETICLE)
                            printAt(midX - 45, drawYStart - 18, e.state .. " [" .. e.hp .. "%]", COLOR_RETICLE, 1)
                        end
                    end
                end
            end
        end
    end
end

-- 7. First-Person Holographic Weapon System Overlay
function drawFirstPersonWeapon(kickOffset, flashActive)
    local centerX = math.floor(SCREEN_W / 2)
    local baseY   = 400
    
    local metalDark   = rgb(22, 24, 28)    
    local metalMid    = rgb(40, 44, 52)    
    local metalLight  = rgb(74, 85, 104)   
    local holoFrame   = rgb(45, 55, 72)    
    local holoReticle = rgb(255, 50, 50)   
    local flashFire   = rgb(255, 190, 40)   
    local flashCore   = rgb(255, 255, 200)  

    local swayX = math.floor(math.sin(millis() * 0.003) * 6)
    local swayY = math.floor(math.cos(millis() * 0.005) * 3)
    
    local gunX = centerX + swayX + math.floor(strafeSwayOffset)
    local gunY = baseY - kickOffset + swayY

    local tiltX = math.floor(weaponTiltAngle * 1.5)
    local tiltY = math.floor(math.abs(weaponTiltAngle) * 0.4)

    if isSliding then
        gunY = gunY + 45  
    end

    if flashActive then
        local fY = (gunY - 140) + tiltY
        local fX = gunX + tiltX
        fillTriangle(fX, fY - 45, fX - 25, fY, fX + 25, fY, flashFire)
        fillTriangle(fX - 40, fY - 15, fX + 40, fY - 15, fX, fY + 15, flashFire)
        circle(fX, fY - 10, 12, flashCore, true)
    end

    fillRect(gunX - 28 + tiltX, gunY - 40, 56, 40, metalDark)
    fillTriangle(gunX + tiltX, gunY - 140 + tiltY, gunX - 12 + tiltX, gunY - 40, gunX + 12 + tiltX, gunY - 40, metalMid)
    
    local opticY = gunY - 55
    fillRect(gunX - 32 + tiltX, opticY - 35 + tiltY, 64, 35, holoFrame)
    rect(gunX - 32 + tiltX, opticY - 35 + tiltY, 64, 35, metalLight)

    local reticleX = centerX
    local reticleY = 200 + camHeightOffset - math.floor(kickOffset * 0.4) 
    circle(reticleX, reticleY, 8, holoReticle, false)
end

-- 8. Advanced Combat & Movement Tick Simulations
function updateTacticalSim()
    if muzzleFlash > 0 then muzzleFlash = muzzleFlash - 1 end
    if weaponKick > 0 then weaponKick = weaponKick - 1 end

    strafeSwayOffset = strafeSwayOffset * 0.75
    weaponTiltAngle  = weaponTiltAngle * 0.75

    if isSliding then
        slideTimer = slideTimer - 1
        camHeightOffset = camHeightOffset + (70 - camHeightOffset) * 0.18

        local nextX = playerX + slideVelX
        local nextY = playerY + slideVelY
        
        if not isTileSolid(nextX, playerY) then playerX = nextX else slideTimer = 0 end
        if not isTileSolid(playerX, nextY) then playerY = nextY else slideTimer = 0 end

        slideVelX = slideVelX * 0.92
        slideVelY = slideVelY * 0.92

        if slideTimer <= 0 then isSliding = false end
    else
        camHeightOffset = camHeightOffset * 0.75
    end

    if isReloading then
        reloadTimer = reloadTimer - 1
        if reloadTimer <= 0 then
            local needed = maxMag - ammoMag
            if reserves >= needed then reserves = reserves - needed; ammoMag = maxMag
            else ammoMag = ammoMag + reserves; reserves = 0 end
            isReloading = false
        end
    end

    for i, e in ipairs(enemies) do
        if e.active then
            local dist = math.sqrt((e.x - playerX)^2 + (e.y - playerY)^2)
            if e.state == "PATROL" then
                if dist < 7.5 then
                    e.state = "COMBAT"
                    for _, ally in ipairs(enemies) do if ally.state == "PATROL" then ally.state = "COMBAT" end end
                else
                    local pDist = math.sqrt((e.x - e.tgtX)^2 + (e.y - e.tgtY)^2)
                    if pDist < 0.2 then
                        e.tgtX = e.x + math.random(-2, 2); e.tgtY = e.y + math.random(-2, 2)
                    else
                        local pAngle = math.atan2(e.tgtY - e.y, e.tgtX - e.x)
                        local nx = e.x + math.cos(pAngle) * 0.015; local ny = e.y + math.sin(pAngle) * 0.015
                        if not isTileSolid(nx, ny) then e.x, e.y = nx, ny end
                    end
                end
            elseif e.state == "COMBAT" then
                if e.hp < 40 then e.state = "RETREAT"; e.cooldown = 120
                else
                    local angleToPlayer = math.atan2(playerY - e.y, playerX - e.x)
                    local moveX = math.cos(angleToPlayer) * 0.03; local moveY = math.sin(angleToPlayer) * 0.03
                    local strafeAngle = angleToPlayer + (math.pi / 2) * e.strafeDir
                    moveX = moveX + math.cos(strafeAngle) * 0.02; moveY = moveY + math.sin(strafeAngle) * 0.02
                    
                    if math.random(1, 80) == 1 or isTileSolid(e.x + moveX, e.y + moveY) then e.strafeDir = e.strafeDir * -1 end
                    local nx, ny = e.x + moveX, e.y + moveY
                    if not isTileSolid(nx, ny) then e.x, e.y = nx, ny end

                    if math.random(1, 35) == 1 and dist < 8.0 then
                        health = health - math.random(3, 7)
                        if health < 0 then health = 0 end
                    end
                end
            elseif e.state == "RETREAT" then
                e.cooldown = e.cooldown - 1
                local angleAway = math.atan2(e.y - playerY, e.x - playerX)
                local nx = e.x + math.cos(angleAway) * 0.045; local ny = e.y + math.sin(angleAway) * 0.045
                if not isTileSolid(nx, ny) then e.x, e.y = nx, ny else e.state = "RECOVER"; e.cooldown = 90 end
                if e.cooldown <= 0 then e.state = "COMBAT" end
            elseif e.state == "RECOVER" then
                e.cooldown = e.cooldown - 1
                if e.cooldown % 10 == 0 then e.hp = e.hp + 5 end
                if e.hp >= e.maxHp then e.hp = e.maxHp; e.state = "COMBAT" end
                if e.cooldown <= 0 then e.state = "COMBAT" end
            end
        end
    end

    local curR = math.floor(playerY); local curC = math.floor(playerX)
    if curR >= 1 and curR <= MAP_HEIGHT and curC >= 1 and curC <= MAP_WIDTH then
        local tile = worldMap[curR][curC]
        if tile == 2 and currentObjective == 1 then currentObjective = 2
        elseif tile == 3 and currentObjective == 2 then currentObjective = 3 end
    end
end

-- 9. Breach Command Execution [E]
function executeTacticalInteraction()
    local checkX = playerX + math.cos(playerAngle) * 1.2
    local checkY = playerY + math.sin(playerAngle) * 1.2
    local mapR = math.floor(checkY); local mapC = math.floor(checkX)

    if mapR >= 1 and mapR <= MAP_HEIGHT and mapC >= 1 and mapC <= MAP_WIDTH then
        if worldMap[mapR][mapC] == 4 then
            worldMap[mapR][mapC] = 0 
            weaponKick = 4
        end
    end
end

-- 10. Firearm Discharge Handler
function fireTacticalWeapon()
    if isReloading or ammoMag <= 0 then return end

    ammoMag = ammoMag - 1
    weaponKick = 16
    muzzleFlash = 3 

    for i, e in ipairs(enemies) do
        if e.active and (e.state == "COMBAT" or e.state == "RETREAT" or e.state == "RECOVER") then
            local angleToPlayer = math.atan2(e.y - playerY, e.x - playerX)
            local diff = math.abs(playerAngle - angleToPlayer)
            if diff < 0.25 then
                e.hp = e.hp - math.random(30, 55)
                if e.state == "PATROL" then e.state = "COMBAT" end
                if e.hp <= 0 then e.active = false end
                break
            end
        end
    end
end

-- 11. Complete Viewport Overlay Drawing Layer
function renderUI()
    drawRaycastView()
    draw3DEntities()
    drawFirstPersonWeapon(weaponKick, muzzleFlash > 0)

    fillRect(0, 400, SCREEN_W, 80, COLOR_HUD_BG)
    fillRect(0, 398, SCREEN_W, 2, COLOR_RETICLE)

    printAt(40, 415, "OPERATIVE VITALS: " .. health .. "%", health > 30 and COLOR_RETICLE or COLOR_ALERT, 1)
    fillRect(40, 435, 200, 12, rgb(30, 35, 45))
    if health > 0 then
        fillRect(40, 435, math.floor(health * 2), 12, health > 30 and rgb(50, 205, 50) or COLOR_ALERT)
    end

    printAt(280, 415, "MISSION PROFILE PROGRESS MATRIX:", rgb(236, 201, 75), 1)
    if currentObjective <= 3 then
        printAt(280, 435, objectiveText[currentObjective], WHITE, 1)
    else
        printAt(280, 435, "CAMPAIGN EXFILTRATION COMPLETE!", rgb(50, 205, 50), 1)
    end

    local ammoTxt = isReloading and "RELOADING..." or (ammoMag .. " / " .. reserves)
    printAt(640, 415, "WEAPON: SIG-P4-CARBINE", COLOR_RETICLE, 1)
    printAt(640, 435, "MAG: " .. ammoTxt, WHITE, 1)

    flush()
end

-- 12. Main Setup Execution Configuration
initGame = function()
    playerX, playerY = 2.5, 2.5
    playerAngle = 0.0
    health = 100; ammoMag = 30; reserves = 120
    currentObjective = 1; isReloading = false; isSliding = false
    for _, e in ipairs(enemies) do e.active = true; e.hp = 100; e.state = "PATROL" end
end

initGame()
showMouse(false)

while true do
    local mx, my, lHold, rHold, scroll, lClick, rClick = getMouse()

    if mx > 0 and mx < SCREEN_W then
        local deltaX = mx - math.floor(SCREEN_W / 2)
        if math.abs(deltaX) > 1 then
            playerAngle = playerAngle + (deltaX * 0.0035)
            setMousePos(math.floor(SCREEN_W / 2), math.floor(SCREEN_H / 2))
        end
    end

    if lClick then fireTacticalWeapon() end

    pollKeys()

    local speed = 0.075
    local mxStep, myStep = 0, 0

    if not isSliding then
        if isKeyDown("w") or isKeyDown("up") then
            mxStep = mxStep + math.cos(playerAngle) * speed
            myStep = myStep + math.sin(playerAngle) * speed
        end
        if isKeyDown("s") or isKeyDown("down") then
            mxStep = mxStep - math.cos(playerAngle) * speed
            myStep = myStep - math.sin(playerAngle) * speed
        end
        if isKeyDown("a") or isKeyDown("left") then
            mxStep = mxStep + math.cos(playerAngle - math.pi/2) * (speed * 0.75)
            myStep = myStep + math.sin(playerAngle - math.pi/2) * (speed * 0.75)
            strafeSwayOffset = 22
            weaponTiltAngle  = 12
        end
        if isKeyDown("d") or isKeyDown("right") then
            mxStep = mxStep + math.cos(playerAngle + math.pi/2) * (speed * 0.75)
            myStep = myStep + math.sin(playerAngle + math.pi/2) * (speed * 0.75)
            strafeSwayOffset = -22
            weaponTiltAngle  = -12
        end

        if isKeyDown("c") then
            if math.abs(mxStep) > 0 or math.abs(myStep) > 0 then
                isSliding  = true
                slideTimer = slideMaxTime
                slideVelX  = (mxStep / speed) * 0.15
                slideVelY  = (myStep / speed) * 0.15
                weaponTiltAngle = 35
            end
        end

        local nX = playerX + mxStep; local nY = playerY + myStep
        if worldMap[math.floor(playerY)][math.floor(nX)] == 0 or worldMap[math.floor(playerY)][math.floor(nX)] >= 2 then playerX = nX end
        if worldMap[math.floor(nY)][math.floor(playerX)] == 0 or worldMap[math.floor(nY)][math.floor(playerX)] >= 2 then playerY = nY end
    end

    if isKeyDown("e") then executeTacticalInteraction(); delay(100) end
    if (isKeyDown("r") or rClick) and not isReloading and ammoMag < maxMag and reserves > 0 then
        isReloading = true; reloadTimer = 75
    end

    if health <= 0 then initGame() end

    updateTacticalSim()
    renderUI()
    
    if shouldQuit() then quit(); break end
    delay(16)
end
