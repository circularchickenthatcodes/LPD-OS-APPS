-- ============================================================
-- RAYCASTER FPS - ESP32-P4 (800x480)
-- Center-lock mouse + WASD strafe
-- Added: Sliding + Slide Cancel
-- Fixed: Strafing direction
-- Upgraded: Animated, Multi-Layer Procedural Enemy Sprites
-- ============================================================

local floor = math.floor
local abs = math.abs
local sqrt = math.sqrt
local sin = math.sin
local cos = math.cos
local random = math.random
local max = math.max
local min = math.min
local atan2 = math.atan2
showMouse(false)

local SW = SCREEN_W or 800
local SH = SCREEN_H or 480
local HW = SW / 2
local HH = SH / 2

local RAY_WIDTH = 4
local RAYS = SW / RAY_WIDTH
local TWO_INV_RAYS = 2 / RAYS

local MOUSE_SENS = 0.006
local TURN_SPEED = 0.04

local health = 100
local ammo = 20
local level = 1
local worldMap = {}
local enemies = {}
local zBuffer = {}
local globalTimer = 0 -- Master clock variable for sprite animations

for i = 0, RAYS - 1 do zBuffer[i] = 999 end

local bob, recoil, flash = 0, 0, 0
local showPopup = false
local popupText = ""
local popupTimer = 0
local showInteractPrompt = false

-- ============================================================
-- SLIDING & SLIDE CANCEL STATE
-- ============================================================
local isSliding = false
local slideTimer = 0
local SLIDE_DURATION = 30       -- frames the slide lasts
local SLIDE_SPEED = 0.18        -- initial slide speed (fast burst)
local SLIDE_FRICTION = 0.92     -- how quickly slide decays each frame
local slideVelX = 0             -- current slide velocity X
local slideVelY = 0             -- current slide velocity Y
local slideCooldown = 0         -- cooldown before next slide
local SLIDE_COOLDOWN_MAX = 20   -- frames before you can slide again
local slideViewDip = 10         -- camera dip during slide
local SLIDE_DIP_MAX = 40        -- max pixels the view dips down
local wasSlidingLastFrame = false

-- Player velocity tracking for movement direction
local playerVelX = 0
local playerVelY = 0

local function generateMap()
    worldMap = {}
    math.randomseed(os.time())
    for x = 1, 14 do
        worldMap[x] = {}
        for y = 1, 14 do
            if x == 1 or x == 14 or y == 1 or y == 14 then
                worldMap[x][y] = 1
            elseif random() > 0.85 then
                worldMap[x][y] = 1
            else
                worldMap[x][y] = 0
            end
        end
    end
    for i = 2, 4 do
        for j = 2, 4 do
            worldMap[i][j] = 0
        end
    end
    local done = false
    while not done do
        local cx = random(5, 13)
        local cy = random(5, 13)
        if worldMap[cx][cy] == 0 then
            worldMap[cx][cy] = 2
            done = true
        end
    end
end

local function spawnEnemies(count)
    enemies = {}
    local spawned = 0
    while spawned < count do
        local ex = random(2, 13)
        local ey = random(2, 13)
        if worldMap[ex][ey] == 0 and (ex > 5 or ey > 5) then
            enemies[#enemies + 1] = {x = ex + 0.5, y = ey + 0.5, alive = true}
            spawned = spawned + 1
        end
    end
end

local function drawHUD()
    local bx, by = 0, 0
    local isMoving = isKeyDown("w") or isKeyDown("s") or isKeyDown("a") or isKeyDown("d")

    if isMoving and not isSliding then
        bob = bob + 0.3
        bx = sin(bob) * 8
        by = abs(cos(bob)) * 5
    elseif isSliding then
        -- Subtle fast bob during slide
        bob = bob + 0.5
        bx = sin(bob) * 3
        by = 0
    end

    recoil = recoil * 0.8
    if flash > 0 then flash = flash - 1 end

    -- Apply slide view dip
    local viewDipOffset = slideViewDip
    local cx, cy = HW + bx, HH - 30 + by - (recoil * 3) + viewDipOffset

    -- Gun butt (wide base grip at bottom)
    drawTrapezoid(cx, cy + 200, 200, cx, cy + 160, 170, 0x2104)
    -- Lower body
    drawTrapezoid(cx, cy + 160, 170, cx, cy + 126, 150, 0x3186)
    -- Upper body
    drawTrapezoid(cx, cy + 126, 150, cx, cy + 70, 120, 0x2104)
    -- Slide / top
    drawTrapezoid(cx, cy + 70, 120, cx, cy + 48, 100, 0x18C3)

    -- Trigger guard (dark cutouts on sides)
    fillRect(cx - 80, cy + 110, 18, 40, 0x0000)
    fillRect(cx + 62, cy + 110, 18, 40, 0x0000)

    -- Grip texture lines
    fillRect(cx - 30, cy + 165, 60, 2, 0x18C3)
    fillRect(cx - 28, cy + 172, 56, 2, 0x18C3)
    fillRect(cx - 26, cy + 179, 52, 2, 0x18C3)
    fillRect(cx - 24, cy + 186, 48, 2, 0x18C3)

    -- Barrel (muzzle hole)
    fillRect(cx - 3, cy + 40, 6, 12, 0x0000)

    -- Muzzle flash
    if flash > 0 then
        fillRect(cx - 40, cy - 15, 80, 60, 0xFB20)
        fillRect(cx - 20, cy, 40, 30, 0xFFE0)
    end

    -- HUD panel
    local nx, ny = HW - 150, SH - 80
    fillRect(nx, ny, 300, 75, 0x3186)
    fillRect(nx + 5, ny + 5, 290, 65, 0x0000)
    setTextSize(2)
    printAt(nx + 15, ny + 15, "AMMO: " .. ammo, 0xFFE0)
    printAt(nx + 15, ny + 40, "HP: " .. health, 0xF800)
    printAt(nx + 160, ny + 15, "LVL:" .. level, 0x07E0)

    -- Slide indicator
    if isSliding then
        printAt(nx + 160, ny + 40, "SLIDE", 0x07FF)
    elseif slideCooldown > 0 then
        printAt(nx + 160, ny + 40, "CD:" .. slideCooldown, 0x7BEF)
    end
    setTextSize(1)

    if showInteractPrompt and not showPopup then
        setTextSize(2)
        printAt(HW - 120, HH - 30, "[E/RMB] COLLECT AMMO", 0xFFFF)
        setTextSize(1)
    end

    if showPopup then
        fillRect(HW - 150, HH - 60, 300, 60, 0x0000)
        rect(HW - 150, HH - 60, 300, 60, 0xFFFF)
        setTextSize(2)
        printAt(HW - 130, HH - 40, popupText, 0xFFFF)
        setTextSize(1)
        popupTimer = popupTimer - 1
        if popupTimer <= 0 then showPopup = false end
    end
end

local function drainInputs()
    local fired = false
    local looted = false

    while true do
        local click = getClick()
        if click == nil then break end
        if click == 1 then fired = true end
        if click == 2 then looted = true end
    end

    while true do
        local key = getKeyPress()
        if key == nil then break end
        if key == 0x2C then fired = true end
        if key == 0x08 then looted = true end
    end

    return fired, looted
end

-- Check if a map cell is passable (0 = empty)
local function isPassable(mx, my)
    if mx < 1 or mx > 14 or my < 1 or my > 14 then return false end
    local row = worldMap[mx]
    if not row then return false end
    return row[my] == 0
end

-- Try to move with wall collision, returns new position
local function tryMove(curX, curY, newX, newY)
    local margin = 0.15
    local resultX, resultY = curX, curY

    -- Check X axis
    local testXL = newX - margin
    local testXR = newX + margin
    if isPassable(floor(testXL), floor(curY - margin)) and
       isPassable(floor(testXL), floor(curY + margin)) and
       isPassable(floor(testXR), floor(curY - margin)) and
       isPassable(floor(testXR), floor(curY + margin)) then
        resultX = newX
    end

    -- Check Y axis
    local testYU = newY - margin
    local testYD = newY + margin
    if isPassable(floor(resultX - margin), floor(testYU)) and
       isPassable(floor(resultX + margin), floor(testYU)) and
       isPassable(floor(resultX - margin), floor(testYD)) and
       isPassable(floor(resultX + margin), floor(testYD)) then
        resultY = newY
    end

    return resultX, resultY
end

generateMap()
spawnEnemies(3)
local px, py, pdx, pdy, plx, ply = 2.5, 2.5, 1, 0, 0, 0.66

setMousePos(HW, HH)

while true do
    globalTimer = globalTimer + 1 -- Increment engine ticking reference
    for i = 0, RAYS - 1 do zBuffer[i] = 999 end

    -- Snapshot key state
    pollKeys()

    -- Mouse input
    local mouseX, mouseY, mLeft, mRight, mScroll, mLeftClick, mRightClick = getMouse()

    -- Drain queued one-shot inputs
    local wantFire, wantLoot = drainInputs()

    -- Mouse look: center-lock
    local mouseDX = mouseX - HW
    if mouseDX ~= 0 then
        local angle = mouseDX * MOUSE_SENS
        local c = cos(angle)
        local s = sin(angle)
        local odx = pdx
        pdx = pdx * c - pdy * s
        pdy = odx * s + pdy * c
        local olx = plx
        plx = plx * c - ply * s
        ply = olx * s + ply * c
    end
    setMousePos(HW, HH)

    -- Keyboard turning
    if isKeyDown("left") then
        local c = cos(-TURN_SPEED)
        local s = sin(-TURN_SPEED)
        local odx = pdx
        pdx = pdx * c - pdy * s
        pdy = odx * s + pdy * c
        local olx = plx
        plx = plx * c - ply * s
        ply = olx * s + ply * c
    end

    if isKeyDown("right") then
        local c = cos(TURN_SPEED)
        local s = sin(TURN_SPEED)
        local odx = pdx
        pdx = pdx * c - pdy * s
        pdy = odx * s + pdy * c
        local olx = plx
        plx = plx * c - ply * s
        ply = olx * s + ply * c
    end

    -- Shooting
    local fireTriggered = false
    if wantFire then
        if ammo > 0 then
            recoil, flash, ammo = 30, 3, ammo - 1
            playSound(150, 20)
            fireTriggered = true
        else
            playSound(50, 10)
        end
    end

    -- ============================================================
    -- MOVEMENT (fixed strafing + sliding)
    -- ============================================================
    local ms = 0.08
    local strafeSpeed = 0.06

    -- Calculate intended movement direction from WASD
    local moveX, moveY = 0, 0

    if isKeyDown("w") then
        moveX = moveX + pdx * ms
        moveY = moveY + pdy * ms
    end
    if isKeyDown("s") then
        moveX = moveX - pdx * ms
        moveY = moveY - pdy * ms
    end
    -- FIXED STRAFING: strafe uses the perpendicular of the direction vector
    if isKeyDown("a") then
        moveX = moveX - (-pdy) * strafeSpeed
        moveY = moveY - pdx * strafeSpeed
    end
    if isKeyDown("d") then
        moveX = moveX + (-pdy) * strafeSpeed
        moveY = moveY + pdx * strafeSpeed
    end

    -- Track player velocity for slide direction
    if abs(moveX) > 0.001 or abs(moveY) > 0.001 then
        playerVelX = moveX
        playerVelY = moveY
    end

    -- ============================================================
    -- SLIDE INITIATION (Left Ctrl or C while moving)
    -- ============================================================
    local wantSlide = isKeyDown("lctrl") or isKeyDown("c")

    if wantSlide and not isSliding and slideCooldown <= 0 then
        -- Must be moving to initiate slide
        local velMag = sqrt(playerVelX * playerVelX + playerVelY * playerVelY)
        if velMag > 0.01 then
            isSliding = true
            slideTimer = SLIDE_DURATION
            -- Normalize movement direction and apply slide speed
            local invMag = 1.0 / velMag
            slideVelX = playerVelX * invMag * SLIDE_SPEED
            slideVelY = playerVelY * invMag * SLIDE_SPEED
            playSound(80, 15)
        end
    end

    -- ============================================================
    -- SLIDE CANCEL: Jump (space) during slide
    -- ============================================================
    if isSliding and isKeyDown("space") then
        isSliding = false
        slideTimer = 0
        slideCooldown = floor(SLIDE_COOLDOWN_MAX / 2)
        local boostMag = sqrt(slideVelX * slideVelX + slideVelY * slideVelY)
        if boostMag > 0.01 then
            local invMag = 1.0 / boostMag
            local boostX = slideVelX * invMag * 0.12
            local boostY = slideVelY * invMag * 0.12
            px, py = tryMove(px, py, px + boostX, py + boostY)
        end
        slideVelX, slideVelY = 0, 0
        slideViewDip = 0
        playSound(200, 10)
    end

    -- ============================================================
    -- APPLY SLIDE MOVEMENT
    -- ============================================================
    if isSliding then
        slideTimer = slideTimer - 1

        -- Apply slide velocity with wall collision
        px, py = tryMove(px, py, px + slideVelX, py + slideVelY)

        -- Decay slide velocity
        slideVelX = slideVelX * SLIDE_FRICTION
        slideVelY = slideVelY * SLIDE_FRICTION

        -- Camera dip effect (crouch feeling)
        local slideProgress = 1.0 - (slideTimer / SLIDE_DURATION)
        if slideProgress < 0.2 then
            slideViewDip = slideProgress * 5 * SLIDE_DIP_MAX
        elseif slideProgress > 0.7 then
            slideViewDip = (1.0 - slideProgress) * (1.0 / 0.3) * SLIDE_DIP_MAX
        else
            slideViewDip = SLIDE_DIP_MAX
        end

        moveX, moveY = 0, 0

        -- End slide when timer runs out or velocity is negligible
        local slideMag = sqrt(slideVelX * slideVelX + slideVelY * slideVelY)
        if slideTimer <= 0 or slideMag < 0.005 then
            isSliding = false
            slideTimer = 0
            slideVelX, slideVelY = 0, 0
            slideCooldown = SLIDE_COOLDOWN_MAX
        end
    else
        slideViewDip = slideViewDip * 0.7
        if abs(slideViewDip) < 1 then slideViewDip = 0 end

        if slideCooldown > 0 then
            slideCooldown = slideCooldown - 1
        end
    end

    -- Apply normal movement (only if not sliding)
    if not isSliding and (abs(moveX) > 0.001 or abs(moveY) > 0.001) then
        px, py = tryMove(px, py, px + moveX, py + moveY)
    end

    -- Raycasting
    local lpx, lpy = px, py
    local lpdx, lpdy = pdx, pdy
    local lplx, lply = plx, ply

    -- Adjust view height during slide for raycasting
    local viewHH = HH + slideViewDip

    for x = 0, RAYS - 1 do
        local camX = x * TWO_INV_RAYS - 1
        local rdx = lpdx + lplx * camX
        local rdy = lpdy + lply * camX
        local mmx, mmy = floor(lpx), floor(lpy)

        local addx = abs(rdx)
        local addy = abs(rdy)
        local ddx = addx > 0.0001 and (1 / addx) or 100000
        local ddy = addy > 0.0001 and (1 / addy) or 100000

        local sx, sy, sdx, sdy
        if rdx < 0 then sx, sdx = -1, (lpx - mmx) * ddx
        else sx, sdx = 1, (mmx + 1 - lpx) * ddx end
        if rdy < 0 then sy, sdy = -1, (lpy - mmy) * ddy
        else sy, sdy = 1, (mmy + 1 - lpy) * ddy end

        local side = 0
        local t = 0

        for step = 1, 30 do
            if sdx < sdy then
                sdx = sdx + ddx
                mmx = mmx + sx
                side = 0
            else
                sdy = sdy + ddy
                mmy = mmy + sy
                side = 1
            end
            local row = worldMap[mmx]
            if row then
                local cell = row[mmy]
                if cell and cell > 0 then
                    t = cell
                    break
                end
            else
                break
            end
        end

        local screenX = x * RAY_WIDTH

        if t == 0 then
            fillRect(screenX, 0, RAY_WIDTH, floor(viewHH), 0x0000)
            fillRect(screenX, floor(viewHH), RAY_WIDTH, SH - floor(viewHH), 0x1082)
        else
            local dist = (side == 0) and (sdx - ddx) or (sdy - ddy)
            if dist < 0.01 then dist = 0.01 end
            zBuffer[x] = dist

            local h = floor(SH / dist)
            local halfH = h / 2
            local dS = viewHH - halfH
            local dE = viewHH + halfH
            if dS < 0 then dS = 0 end
            if dE > SH then dE = SH end

            local color
            if t == 2 then color = 0xC260
            elseif side == 1 then color = 0x2104
            else color = 0x3186 end

            if dS > 0 then
                fillRect(screenX, 0, RAY_WIDTH, dS, 0x0000)
            end
            local wallH = dE - dS
            if wallH > 0 then
                fillRect(screenX, dS, RAY_WIDTH, wallH, color)
            end
            if dE < SH then
                fillRect(screenX, dE, RAY_WIDTH, SH - dE, 0x1082)
            end
        end
    end

    -- Enemies
    local anyAlive = false
    for i = 1, #enemies do
        local e = enemies[i]
        if e.alive then
            anyAlive = true

            -- Enemy AI movement with wall collision
            local angle = atan2(lpy - e.y, lpx - e.x)
            local speed = 0.045
            local enx = e.x + cos(angle) * speed
            local eny = e.y + sin(angle) * speed

            enx, eny = tryMove(e.x, e.y, enx, eny)
            e.x = enx
            e.y = eny

            -- Damage player if close
            local dx = lpx - e.x
            local dy = lpy - e.y
            local distSq = dx * dx + dy * dy

            if distSq < 0.2025 then
                health = health - 1
                if health <= 0 then
                    cls(0xF800)
                    setTextSize(4)
                    printAt(250, 200, "GAME OVER", 0xFFFF)
                    setTextSize(2)
                    printAt(280, 260, "Level: " .. level, 0xFFFF)
                    flush()
                    delay(3000)
                    health, ammo, level = 100, 20, 1
                    isSliding = false
                    slideTimer = 0
                    slideCooldown = 0
                    slideVelX, slideVelY = 0, 0
                    slideViewDip = 0
                    generateMap()
                    spawnEnemies(3)
                    px, py = 2.5, 2.5
                    lpx, lpy = px, py
                    setMousePos(HW, HH)
                    setTextSize(1)
                end
            end

            -- Sprite projection
            local spx = e.x - lpx
            local spy = e.y - lpy
            local det = lplx * lpdy - lpdx * lply
            if abs(det) > 0.0001 then
                local invDet = 1.0 / det
                local tx = invDet * (lpdy * spx - lpdx * spy)
                local ty = invDet * (-lply * spx + lplx * spy)

                if ty > 0.3 then
                    local spriteScreenX = floor(HW * (1 + tx / ty))

                    local spriteH = abs(floor(SH / ty))
                    local spriteW = spriteH / 2
                    local drawX = spriteScreenX - spriteW / 2
                    local drawY = viewHH - spriteH / 2

                    local startCol = drawX
                    local endCol = drawX + spriteW
                    if startCol < 0 then startCol = 0 end
                    if endCol > SW then endCol = SW end

                    local startY = drawY
                    local drawH = spriteH
                    if startY < 0 then
                        drawH = drawH + startY
                        startY = 0
                    end
                    if startY + drawH > SH then
                        drawH = SH - startY
                    end

                    -- ============================================================
                    -- UPGRADED SPRITE RASTERIZATION PIPELINE (PROCEDURAL PRIMITIVES)
                    -- ============================================================
                    if drawH > 0 then
                        local col = startCol
                        while col < endCol do
                            local rayIdx = floor(col / RAY_WIDTH)
                            
                            -- Check z-buffer depth map to handle wall occlusions cleanly
                            if rayIdx >= 0 and rayIdx < RAYS and ty < zBuffer[rayIdx] then
                                local stripW = RAY_WIDTH
                                if col + stripW > endCol then stripW = endCol - col end
                                
                                if stripW > 0 then
                                    -- Calculate column local space (0.0 to 1.0 across the width)
                                    local texX = (col - drawX) / spriteW
                                    
                                    -- Check if enemy was hit to flash the column yellow/white
                                    if fireTriggered and abs(spriteScreenX - HW) < 50 then
                                        fillRect(col, startY, stripW, drawH, 0xFFFF)
                                    else
                                        -- Dynamic Vertical Slicing Framework
                                        local headHeight = floor(drawH * 0.25)
                                        local bodyHeight = floor(drawH * 0.55)
                                        local legsHeight = drawH - headHeight - bodyHeight
                                        
                                        local yHead = startY
                                        local yBody = startY + headHeight
                                        local yLegs = yBody + bodyHeight
                                        
                                        -- 1. Render Head Row (Obsidian helmet armor)
                                        if texX > 0.2 and texX < 0.8 then
                                            fillRect(col, yHead, stripW, headHeight, 0x4208)
                                        end
                                        
                                        -- 2. Render Body Row (Crimson carapace core)
                                        if texX > 0.1 and texX < 0.9 then
                                            local bodyColor = 0xF800
                                            -- Draw dark spine layout down center column
                                            if texX > 0.45 and texX < 0.53 then 
                                                bodyColor = 0x1082 
                                            end
                                            fillRect(col, yBody, stripW, bodyHeight, bodyColor)
                                        end
                                        
                                        -- 3. Render Legs Row (Animated running stride)
                                        local legStride = sin(globalTimer * 0.2 + i) * 0.25
                                        local leftLegActive = (texX > 0.15 and texX < 0.35) and (legStride > 0)
                                        local rightLegActive = (texX > 0.65 and texX < 0.85) and (legStride <= 0)
                                        local centerLegStrut = (texX > 0.42 and texX < 0.58)
                                        
                                        if leftLegActive or rightLegActive or centerLegStrut then
                                            fillRect(col, yLegs, stripW, legsHeight, 0x2104)
                                        end
                                    end
                                end
                            end
                            col = col + RAY_WIDTH
                        end

                        -- --- Overlaid Custom Emissive Face Details ---
                        local centerRay = floor(spriteScreenX / RAY_WIDTH)
                        if centerRay >= 0 and centerRay < RAYS and ty < zBuffer[centerRay] then
                            local eyeY = viewHH - spriteH / 4
                            if eyeY >= 0 and eyeY < SH then
                                local eyeSize = max(2, floor(spriteH / 14))
                                local leftEyeX = spriteScreenX - spriteW / 5
                                local rightEyeX = spriteScreenX + spriteW / 5 - eyeSize
                                
                                -- Neon Cyan glowing visor pods
                                if leftEyeX >= 0 and leftEyeX + eyeSize <= SW then
                                    fillRect(leftEyeX, eyeY, eyeSize, eyeSize, 0x07FF)
                                end
                                if rightEyeX >= 0 and rightEyeX + eyeSize <= SW then
                                    fillRect(rightEyeX, eyeY, eyeSize, eyeSize, 0x07FF)
                                end
                            end
                        end
                    end

                    if fireTriggered and abs(spriteScreenX - HW) < 50 then
                        e.alive = false
                        playSound(100, 30)
                    end
                end
            end
        end
    end

    -- Crosshair (adjusted for slide dip)
    local crossY = floor(viewHH)
    fillRect(HW - 1, crossY - 10, 2, 20, 0x07E0)
    fillRect(HW - 10, crossY - 1, 20, 2, 0x07E0)

    -- Crate looting
    showInteractPrompt = false
    local lootX, lootY = -1, -1
    local pmx, pmy = floor(lpx), floor(lpy)

    for ix = -1, 1 do
        local checkX = pmx + ix
        if checkX >= 1 and checkX <= 14 then
            local row = worldMap[checkX]
            if row then
                for iy = -1, 1 do
                    local checkY = pmy + iy
                    if checkY >= 1 and checkY <= 14 and row[checkY] == 2 then
                        local ddx = lpx - (checkX + 0.5)
                        local ddy = lpy - (checkY + 0.5)
                        if ddx * ddx + ddy * ddy < 1.96 then
                            showInteractPrompt = true
                            lootX, lootY = checkX, checkY
                        end
                    end
                end
            end
        end
    end

    if wantLoot and showInteractPrompt and not showPopup then
        local refill = random(10, 15)
        ammo = ammo + refill
        worldMap[lootX][lootY] = 0
        popupText = "REFILLED +" .. refill .. " AMMO"
        showPopup = true
        popupTimer = 60
        playSound(400, 50)
    end

    -- Next level
    if not anyAlive then
        level = level + 1
        isSliding = false
        slideTimer = 0
        slideCooldown = 0
        slideVelX, slideVelY = 0, 0
        slideViewDip = 0
        collectgarbage("collect")
        generateMap()
        spawnEnemies(2 + level)
        px, py = 2.5, 2.5
        setMousePos(HW, HH)
        cls(0xFFFF)
        setTextSize(3)
        printAt(250, 220, "LEVEL " .. level, 0x0000)
        flush()
        delay(1000)
        setTextSize(1)
        for i = 0, RAYS - 1 do zBuffer[i] = 999 end
    end

    drawHUD()
    flush()

    delay(1)
    if isKeyDown("esc") then return end
end
