-- ============================================
-- CULT OF THE DUNGEON
-- 800x480 ESP32-P4 Edition - Optimized
-- ============================================

-- ============ CACHED MATH ============
local floor = math.floor
local abs = math.abs
local sqrt = math.sqrt
local sin = math.sin
local cos = math.cos
local random = math.random
local max = math.max
local min = math.min

local function rnd(n) return random(n) end
local function rnd2(a, b) return random(a, b) end
local function sign(n) return n > 0 and 1 or n < 0 and -1 or 0 end
local function clamp(v, lo, hi) return v < lo and lo or v > hi and hi or v end

local function dist2(ax, ay, bx, by)
local dx = ax - bx
local dy = ay - by
return dx * dx + dy * dy
end

local function dist(ax, ay, bx, by)
return sqrt(dist2(ax, ay, bx, by))
end

-- ============ SAFE DRAW ============
local function fr(x, y, w, h, c)
  if w < 1 then w = 1 end
  if h < 1 then h = 1 end
  fillRect(floor(x), floor(y), floor(w), floor(h), c or 0)
end

local function pr(x, y, s, c)
  printAt(floor(x), floor(y), tostring(s), c or 0xFFFF)
end

-- ============ COLORS ============
local C = {
  BLACK = 0x0000, WHITE = 0xFFFF, DARK  = 0x2104,
  FLOOR = 0x4208, FLOOR2 = 0x5290, WALL  = 0x8C51,
  WALL2 = 0xAD55, PLAYER = 0xFFE0, ENEMY = 0xF800,
  ENEMY2 = 0xFC00, BOSS = 0xF81F, FOLLOWER= 0x07FF,
  HEART = 0xF800, GOLD = 0xFFE0, EXP  = 0x07E0,
  DOOR  = 0xFD20, DOOR2 = 0xC980, CHEST = 0xFFE0,
  CHEST2 = 0xC980, BULLET = 0xFFE0, BLOOD = 0x8000,
  SPARK = 0xFFFF, UI_BG = 0x2104, UI_BAR = 0xF800,
  UI_BAR2 = 0x07E0, PURPLE = 0x780F, RITUAL = 0xF81F,
  SHADOW = 0x18C3, RED  = 0xF800, CYAN  = 0x07FF,
  GUN  = 0xC618,
}

-- ============ CONSTANTS ============
local SW  = SCREEN_W or 800
local SH  = SCREEN_H or 480
local TILE = 24
local MAP_W = 30
local MAP_H = 18
local HUD_H = 28

-- ============ ENEMY TYPES ============
local E_SLIME = 1
local E_SKULL = 2
local E_KNIGHT = 3
local E_BOSS = 4

-- ============ GAME STATE ============
local state   = "menu"
local frame   = 0
local flashTimer = 0
local flashMsg  = ""
local flashCol  = C.WHITE
local bossDefeated = false
local needFullRedraw = true

-- ============ CAMERA ============
local cam = {x = 0, y = 0, lx = -1, ly = -1}

-- ============ PLAYER ============
local P = {
  x = 0, y = 0, tx = 2, ty = 2,
  hp = 6, maxHp = 6,
  xp = 0, xpNext = 10,
  level = 1, gold = 0,
  attack = 1, def = 0,
  facing = "down",
  moveTimer = 0, shootTimer = 0,
  invTimer = 0,
  followers = 0, faith = 0,
  ritual = false, ritualTimer = 0,
  dead = false, kills = 0,
  ox = nil, oy = nil,
}

-- ============ TABLES ============
local enemies  = {}
local followers = {}
local particles = {}
local projectiles = {}
local items   = {}
local rooms   = {}
local map    = {}
local altar   = {tx = 0, ty = 0, active = false}

-- ============ SCREEN HELPERS ============
local function inScreen(sx, sy)
  return sx > -TILE and sx < SW + TILE and sy > -TILE and sy < SH + TILE
end

-- ============ MAP ============
local function initMap()
  map = {}
  for y = 1, MAP_H do
    map[y] = {}
    for x = 1, MAP_W do map[y][x] = 1 end
  end
end

local function getTile(x, y)
  if x >= 1 and x <= MAP_W and y >= 1 and y <= MAP_H then
    return map[y][x]
  end
  return 1
end

local function isWalkable(x, y)
  local t = getTile(x, y)
  return t == 0 or t == 2 or t == 3
end

local function setTile(x, y, v)
  if x >= 1 and x <= MAP_W and y >= 1 and y <= MAP_H then
    map[y][x] = v
  end
end

-- ============ TILE DRAWING ============
local function drawTile(tx, ty)
  local t = getTile(tx, ty)
  local sx = tx * TILE - cam.x
  local sy = ty * TILE - cam.y
  if not inScreen(sx, sy) then return end

  if t == 1 then
    fr(sx, sy, TILE, TILE, C.WALL)
    fr(sx, sy, TILE, 1, C.WALL2)
    fr(sx, sy, 1, TILE, C.WALL2)
    fr(sx + TILE - 1, sy, 1, TILE, C.DARK)
    fr(sx, sy + TILE - 1, TILE, 1, C.DARK)
  elseif t == 0 then
    local c = ((tx + ty) % 2 == 0) and C.FLOOR or C.FLOOR2
    fr(sx, sy, TILE, TILE, c)
    fr(sx, sy, TILE, 1, C.DARK)
    fr(sx, sy, 1, TILE, C.DARK)
  elseif t == 2 then
    fr(sx, sy, TILE, TILE, C.DOOR2)
    fr(sx + 3, sy + 3, TILE - 6, TILE - 6, C.DOOR)
    fr(sx + 8, sy + 8, 8, 8, C.GOLD)
  elseif t == 3 then
    fr(sx, sy, TILE, TILE, C.FLOOR)
    fr(sx + 3, sy + 6, TILE - 6, TILE - 8, C.CHEST2)
    fr(sx + 3, sy + 6, TILE - 6, 6, C.CHEST)
    fr(sx + 7, sy + 9, 10, 3, C.GOLD)
  end
end

local function eraseSpriteAt(sx, sy, pw, ph)
  if sx == nil then return end
  local tx1 = floor((sx + cam.x) / TILE)
  local ty1 = floor((sy + cam.y) / TILE)
  local tx2 = floor((sx + cam.x + pw - 1) / TILE)
  local ty2 = floor((sy + cam.y + ph - 1) / TILE)
  for ty = ty1, ty2 do
    for tx = tx1, tx2 do
      drawTile(tx, ty)
    end
  end
end

local function drawMapFull()
  local stx = floor(cam.x / TILE)
  local sty = floor(cam.y / TILE)
  local etx = stx + floor(SW / TILE) + 2
  local ety = sty + floor(SH / TILE) + 2
  for ty = sty, ety do
    for tx = stx, etx do
      drawTile(tx, ty)
    end
  end
end

-- ============ PARTICLES ============
local function spawnParticle(x, y, vx, vy, life, c, sz)
  if #particles >= 50 then return end
  particles[#particles + 1] = {
    x = x, y = y, vx = vx, vy = vy,
    life = life, col = c or C.WHITE,
    sz = sz or 2, ox = nil, oy = nil,
  }
end

local function spawnBlood(x, y, n)
  for i = 1, n do
    spawnParticle(x, y, random() * 4 - 2, random() * 4 - 2,
      rnd2(8, 20), C.BLOOD, rnd2(1, 3))
  end
end

local function spawnSparks(x, y, n, c)
  for i = 1, n do
    spawnParticle(x, y, random() * 6 - 3, random() * 6 - 3,
      rnd2(5, 12), c or C.SPARK, 1)
  end
end

local function spawnGoldPop(x, y)
  for i = 1, 5 do
    local a = (i / 5) * 6.283
    local spd = random() * 2 + 1
    spawnParticle(x, y, cos(a) * spd, sin(a) * spd,
      rnd2(10, 18), C.GOLD, 2)
  end
end

local function updateParticles()
  for i = #particles, 1, -1 do
    local p = particles[i]
    if p.ox then eraseSpriteAt(p.ox, p.oy, p.sz + 1, p.sz + 1) end
    p.x = p.x + p.vx
    p.y = p.y + p.vy
    p.vy = p.vy + 0.08
    p.vx = p.vx * 0.95
    p.life = p.life - 1
    if p.life <= 0 then
      table.remove(particles, i)
    else
      p.ox = nil
      p.oy = nil
    end
  end
end

-- ============ DUNGEON GENERATION ============
local function carveRoom(x1, y1, x2, y2)
  for y = y1, y2 do
    for x = x1, x2 do
      if x >= 1 and x <= MAP_W and y >= 1 and y <= MAP_H then
        map[y][x] = 0
      end
    end
  end
end

local function carveCorridor(x1, y1, x2, y2)
  local cx = x1
  while cx ~= x2 do
    if cx >= 1 and cx <= MAP_W and y1 >= 1 and y1 <= MAP_H then
      map[y1][cx] = 0
    end
    cx = cx + sign(x2 - cx)
  end
  local cy = y1
  while cy ~= y2 do
    if x2 >= 1 and x2 <= MAP_W and cy >= 1 and cy <= MAP_H then
      map[cy][x2] = 0
    end
    cy = cy + sign(y2 - cy)
  end
end

local function enemyAtTile(tx, ty)
  for i = 1, #enemies do
    local e = enemies[i]
    if not e.dead and e.tx == tx and e.ty == ty then return true end
  end
  return false
end

local function generateDungeon()
  initMap()
  rooms = {}
  enemies = {}
  followers = {}
  items = {}
  particles = {}
  projectiles = {}
  bossDefeated = false
  needFullRedraw = true

  local attempts = 0
  while #rooms < 10 and attempts < 300 do
    attempts = attempts + 1
    local rw = rnd2(4, 9)
    local rh = rnd2(3, 7)
    local rx = rnd2(2, MAP_W - rw - 1)
    local ry = rnd2(2, MAP_H - rh - 1)
    local ok = true
    for _, r in ipairs(rooms) do
      if rx <= r.x2 + 1 and rx + rw >= r.x1 - 1 and
       ry <= r.y2 + 1 and ry + rh >= r.y1 - 1 then
        ok = false
        break
      end
    end
    if ok then
      rooms[#rooms + 1] = {
        x1 = rx, y1 = ry, x2 = rx + rw, y2 = rx + rh,
        cx = rx + floor(rw / 2), cy = ry + floor(rh / 2),
      }
      carveRoom(rx, ry, rx + rw, ry + rh)
    end
  end

  for i = 2, #rooms do
    carveCorridor(rooms[i - 1].cx, rooms[i - 1].cy,
           rooms[i].cx, rooms[i].cy)
  end

  local r1 = rooms[1]
  P.tx = r1.cx
  P.ty = r1.cy
  P.x = r1.cx * TILE
  P.y = r1.cy * TILE
  P.ox = nil

  if #rooms >= 2 then
    altar.tx = rooms[2].cx
    altar.ty = rooms[2].cy
    altar.active = true
  end

  local lastR = rooms[#rooms]
  enemies[#enemies + 1] = {
    tx = lastR.cx, ty = lastR.cy,
    x = lastR.cx * TILE, y = lastR.cy * TILE,
    hp = 25, maxHp = 25, attack = 2, etype = E_BOSS,
    moveTimer = 0, attackTimer = 0, anim = 0,
    stunTimer = 0, dead = false, ox = nil, oy = nil,
  }

  for ri = 2, #rooms - 1 do
    local r = rooms[ri]
    for e = 1, rnd2(1, 3) do
      local et = rnd2(1, 3)
      local ehp = (et == 3) and 5 or (et == 2) and 3 or 2
      local etx = rnd2(r.x1 + 1, r.x2 - 1)
      local ety = rnd2(r.y1 + 1, r.y2 - 1)
      enemies[#enemies + 1] = {
        tx = etx, ty = ety, x = etx * TILE, y = ety * TILE,
        hp = ehp, maxHp = ehp, attack = 1, etype = et,
        moveTimer = 0, attackTimer = 0, anim = 0,
        stunTimer = 0, dead = false, ox = nil, oy = nil,
      }
    end
  end

  local maxCR = max(2, #rooms - 2)
  for ri = 2, maxCR do
    local r = rooms[ri]
    if rnd(3) == 1 then
      local cx2 = rnd2(r.x1 + 1, r.x2 - 1)
      local cy2 = rnd2(r.y1 + 1, r.y2 - 1)
      if cx2 >= 1 and cx2 <= MAP_W and cy2 >= 1 and cy2 <= MAP_H then
        map[cy2][cx2] = 3
      end
    end
    if rnd(2) == 1 then
      items[#items + 1] = {
        tx = rnd2(r.x1 + 1, r.x2 - 1),
        ty = rnd2(r.y1 + 1, r.y2 - 1),
        itype = rnd(2) == 1 and "gold" or "hp",
        value = rnd2(1, 3), anim = 0, ox = nil, oy = nil,
      }
    end
  end

  for ri = 3, min(#rooms - 1, 6) do
    if rnd(3) == 1 then
      local r = rooms[ri]
      followers[#followers + 1] = {
        tx = r.x1 + 1, ty = r.y1 + 1,
        x = (r.x1 + 1) * TILE, y = (r.y1 + 1) * TILE,
        recruited = false, anim = 0, ox = nil, oy = nil,
      }
    end
  end
end

-- ============ CAMERA ============
local function updateCamera()
  local tx = P.x - floor(SW / 2) + floor(TILE / 2)
  local ty = P.y - floor(SH / 2) + floor(TILE / 2)
  cam.x = clamp(tx, 0, MAP_W * TILE - SW)
  cam.y = clamp(ty, 0, MAP_H * TILE - SH)
  if cam.x ~= cam.lx or cam.y ~= cam.ly then
    needFullRedraw = true
    P.ox = nil
    for i = 1, #enemies do enemies[i].ox = nil end
    for i = 1, #particles do particles[i].ox = nil end
    for i = 1, #projectiles do projectiles[i].ox = nil end
    for i = 1, #items do items[i].ox = nil end
    for i = 1, #followers do followers[i].ox = nil end
    cam.lx = cam.x
    cam.ly = cam.y
  end
end

-- ============ BULLETS ============
local function spawnBullet(x, y, vx, vy)
  if #projectiles < 20 then
    projectiles[#projectiles + 1] = {
      x = x, y = y, vx = vx, vy = vy,
      dmg = P.attack + (P.ritual and 1 or 0),
      life = 50, ox = nil, oy = nil,
    }
  end
end

local function doShoot()
  if P.shootTimer > 0 then return end
  P.shootTimer = 10
  local dx, dy = 0, 0
  if  P.facing == "up"  then dy = -1
  elseif P.facing == "down" then dy = 1
  elseif P.facing == "left" then dx = -1
  elseif P.facing == "right" then dx = 1 end
  spawnBullet(P.x + 12 + dx * 8, P.y + 12 + dy * 8, dx * 6, dy * 6)
  playSound(440, 30)
end

local function updateProjectiles()
  for i = #projectiles, 1, -1 do
    local p = projectiles[i]
    if p.ox then eraseSpriteAt(p.ox - 1, p.oy - 1, 8, 8) end
    p.x = p.x + p.vx
    p.y = p.y + p.vy
    p.life = p.life - 1
    local ptx = floor(p.x / TILE)
    local pty = floor(p.y / TILE)
    local removed = false

    if not isWalkable(ptx, pty) then
      spawnSparks(p.x, p.y, 3)
      table.remove(projectiles, i)
      removed = true
    else
      for _, e in ipairs(enemies) do
        if not e.dead then
          local ex = e.x + 12
          local ey = e.y + 12
          if abs(p.x - ex) < 12 and abs(p.y - ey) < 12 then
            e.hp = e.hp - p.dmg
            e.stunTimer = 10
            spawnBlood(ex, ey, 5)
            playSound(660, 40)
            if e.hp <= 0 then
              e.dead = true
              if e.ox then
                eraseSpriteAt(e.ox - 2, e.oy - 10, 28, 36)
              end
              P.kills = P.kills + 1
              if e.etype == E_BOSS then
                P.xp = P.xp + 5
                P.gold = P.gold + 10
                bossDefeated = true
                flashMsg = "BOSS DEFEATED!"
                flashTimer = 90
                flashCol = C.RITUAL
                playSound(1047, 300)
              else
                P.xp = P.xp + (e.etype == E_KNIGHT and 3 or 2)
                P.gold = P.gold + rnd2(1, 3)
              end
              spawnBlood(ex, ey, 10)
              spawnGoldPop(ex, ey)
              playSound(880, 80)
            end
            table.remove(projectiles, i)
            removed = true
            break
          end
        end
      end
    end
    if not removed then
      if p.life <= 0 then
        table.remove(projectiles, i)
      else
        p.ox = nil
        p.oy = nil
      end
    end
  end
end

-- ============ ENEMY AI ============
local function updateEnemies()
  for _, e in ipairs(enemies) do
    if not e.dead then
      e.anim = (e.anim + 1) % 30
      if e.stunTimer > 0 then e.stunTimer = e.stunTimer - 1 end
      e.moveTimer = e.moveTimer + 1
      e.attackTimer = e.attackTimer + 1

      local spd
      if  e.etype == E_BOSS then spd = 22
      elseif e.etype == E_KNIGHT then spd = 18
      elseif e.etype == E_SKULL then spd = 14
      else spd = 28 end

      if e.stunTimer == 0 and e.moveTimer >= spd then
        e.moveTimer = 0
        local d = dist(e.tx, e.ty, P.tx, P.ty)
        if d < 14 then
          local ddx = P.tx - e.tx
          local ddy = P.ty - e.ty
          local mx, my = 0, 0
          if abs(ddx) > abs(ddy) then mx = sign(ddx)
          else my = sign(ddy) end

          if e.etype == E_BOSS and e.hp <= floor(e.maxHp / 2) then
            mx = sign(ddx)
            my = sign(ddy)
          end
          if e.etype == E_SLIME and rnd(4) == 1 then
            mx = rnd2(-1, 1)
            my = rnd2(-1, 1)
          end

          local nx = e.tx + mx
          local ny = e.ty + my
          if isWalkable(nx, ny) and
           not (nx == P.tx and ny == P.ty) and
           not enemyAtTile(nx, ny) then
            if e.ox then
              eraseSpriteAt(e.ox - 2, e.oy - 10, 28, 36)
            end
            e.tx = nx
            e.ty = ny
            e.x = nx * TILE
            e.y = ny * TILE
            e.ox = nil
          end

          if d <= 1.5 and e.attackTimer >= 25 then
            e.attackTimer = 0
            if P.invTimer == 0 then
              local dmg = max(0, e.attack - P.def)
              P.hp = P.hp - dmg
              P.invTimer = 40
              spawnBlood(P.x + 12, P.y + 12, 5)
              playSound(150, 100)
              if P.hp <= 0 then
                P.dead = true
                state = "death"
                playSound(80, 500)
              end
            end
          end
        end
      end
    end
  end
end

-- ============ PICKUPS ============
local function checkPickup()
  for i = #items, 1, -1 do
    local it = items[i]
    if it.tx == P.tx and it.ty == P.ty then
      if it.ox then eraseSpriteAt(it.ox, it.oy - 3, TILE, TILE + 6) end
      if it.itype == "gold" then
        P.gold = P.gold + it.value
        flashMsg = "+" .. it.value .. " Gold!"
        flashTimer = 45
        flashCol = C.GOLD
        spawnGoldPop(P.x + 12, P.y + 12)
        playSound(660, 80)
      elseif it.itype == "hp" then
        P.hp = min(P.maxHp, P.hp + it.value)
        flashMsg = "+" .. it.value .. " HP!"
        flashTimer = 45
        flashCol = C.EXP
        spawnSparks(P.x + 12, P.y + 12, 6, C.EXP)
        playSound(880, 80)
      end
      table.remove(items, i)
    end
  end

  if getTile(P.tx, P.ty) == 3 then
    setTile(P.tx, P.ty, 0)
    drawTile(P.tx, P.ty)
    local g = rnd2(3, 8)
    P.gold = P.gold + g
    flashMsg = "CHEST! +" .. g .. " Gold"
    flashTimer = 60
    flashCol = C.GOLD
    spawnGoldPop(P.x + 12, P.y + 12)
    playSound(880, 150)
    if rnd(3) == 1 then P.hp = min(P.maxHp, P.hp + 1) end
  end

  if altar.active and P.tx == altar.tx and P.ty == altar.ty then
    if P.gold >= 5 and not P.ritual then
      P.gold = P.gold - 5
      P.ritual = true
      P.ritualTimer = 300
      P.faith = P.faith + 10
      flashMsg = "RITUAL POWER! DMG UP!"
      flashTimer = 90
      flashCol = C.RITUAL
      spawnSparks(P.x + 12, P.y + 12, 15, C.RITUAL)
      playSound(440, 200)
    elseif P.ritual then
      flashMsg = "RITUAL ACTIVE!"
      flashTimer = 30
      flashCol = C.RITUAL
    else
      flashMsg = "NEED 5 GOLD FOR RITUAL"
      flashTimer = 45
      flashCol = C.GOLD
    end
  end
end

local function checkFollowers()
  for _, f in ipairs(followers) do
    if not f.recruited and f.tx == P.tx and f.ty == P.ty then
      f.recruited = true
      if f.ox then eraseSpriteAt(f.ox, f.oy - 6, TILE + 6, TILE + 12) end
      P.followers = P.followers + 1
      P.faith = P.faith + 5
      flashMsg = "FOLLOWER RECRUITED!"
      flashTimer = 60
      flashCol = C.FOLLOWER
      spawnSparks(f.x + 12, f.y + 12, 10, C.FOLLOWER)
      playSound(660, 150)
    end
  end
end

local function checkLevelUp()
  if P.xp >= P.xpNext then
    P.xp = P.xp - P.xpNext
    P.level = P.level + 1
    P.xpNext = P.xpNext + 5
    P.attack = P.attack + 1
    P.maxHp = P.maxHp + 2
    P.hp = min(P.hp + 2, P.maxHp)
    flashMsg = "LEVEL UP! Lv " .. P.level
    flashTimer = 90
    flashCol = C.EXP
    spawnSparks(P.x + 12, P.y + 12, 15, C.EXP)
    playSound(1047, 200)
  end
end

local function updateRitual()
  if not P.ritual then return end
  P.ritualTimer = P.ritualTimer - 1
  if P.ritualTimer <= 0 then
    P.ritual = false
    flashMsg = "RITUAL ENDED"
    flashTimer = 45
    flashCol = C.PURPLE
  end
  if frame % 60 == 0 then
    for _, e in ipairs(enemies) do
      if not e.dead and dist(P.tx, P.ty, e.tx, e.ty) < 4 then
        e.hp = e.hp - 1
        spawnSparks(e.x + 12, e.y + 12, 4, C.RITUAL)
        if e.hp <= 0 then
          e.dead = true
          if e.ox then eraseSpriteAt(e.ox - 2, e.oy - 10, 28, 36) end
          P.kills = P.kills + 1
          P.xp = P.xp + 2
          P.gold = P.gold + 1
          spawnBlood(e.x + 12, e.y + 12, 8)
        end
      end
    end
  end
end

-- ============ INPUT ============
local function handleInput()
  if P.dead then return end
  if P.moveTimer > 0 then P.moveTimer = P.moveTimer - 1 end

  local mx, my = 0, 0
  if  isKeyDown("w") then my = -1 P.facing = "up"
  elseif isKeyDown("s") then my = 1 P.facing = "down" end
  if  isKeyDown("a") then mx = -1 P.facing = "left"
  elseif isKeyDown("d") then mx = 1 P.facing = "right" end

  if P.moveTimer == 0 and (mx ~= 0 or my ~= 0) then
    local nx = P.tx + mx
    local ny = P.ty + my
    if isWalkable(nx, ny) and not enemyAtTile(nx, ny) then
      if P.ox then eraseSpriteAt(P.ox - 6, P.oy - 8, 44, 40) end
      P.tx = nx
      P.ty = ny
      P.x = nx * TILE
      P.y = ny * TILE
      P.moveTimer = 7
      P.ox = nil
    else
      P.moveTimer = 3
    end
  end

  if isKeyDown("space") then doShoot() end
  if P.shootTimer > 0 then P.shootTimer = P.shootTimer - 1 end
  if P.invTimer > 0 then P.invTimer = P.invTimer - 1 end
end

-- ============ DRAW SPRITES ============
local function drawAltar()
  if not altar.active then return end
  local sx = altar.tx * TILE - cam.x
  local sy = altar.ty * TILE - cam.y
  if not inScreen(sx, sy) then return end
  fr(sx + 2, sy + 6, TILE - 4, TILE - 8, C.WALL2)
  fr(sx + 4, sy + 3, TILE - 8, 6, C.WALL)
  local pulse = floor(sin(frame * 0.1) * 3)
  fr(sx + 8 + pulse, sy + 1, 6, 3, C.RITUAL)
  if frame % 20 < 10 then
    fr(sx + 5, sy + 4, 3, 3, C.RITUAL)
    fr(sx + 16, sy + 4, 3, 3, C.RITUAL)
  end
end

local function drawItems()
  for _, it in ipairs(items) do
    it.anim = (it.anim + 1) % 60
    local sx = it.tx * TILE - cam.x
    local sy = it.ty * TILE - cam.y
    local bob = floor(sin(it.anim * 0.2) * 3)
    if inScreen(sx, sy) then
      if it.ox then eraseSpriteAt(it.ox, it.oy - 3, TILE, TILE + 6) end
      if it.itype == "gold" then
        fr(sx + 6, sy + 6 + bob, 12, 12, C.GOLD)
        fr(sx + 8, sy + 8 + bob, 8, 8, C.WHITE)
      elseif it.itype == "hp" then
        fr(sx + 7, sy + 4 + bob, 10, 3, C.HEART)
        fr(sx + 4, sy + 7 + bob, 16, 6, C.HEART)
        fr(sx + 7, sy + 13 + bob, 10, 3, C.HEART)
      end
      it.ox = sx
      it.oy = sy + bob
    end
  end
end

local function drawFollowers()
  for _, f in ipairs(followers) do
    if not f.recruited then
      f.anim = (f.anim + 1) % 40
      local sx = f.tx * TILE - cam.x
      local sy = f.ty * TILE - cam.y
      local bob = f.anim < 20 and 0 or 1
      if inScreen(sx, sy) then
        if f.ox then eraseSpriteAt(f.ox - 3, f.oy - 6, TILE + 6, TILE + 12) end
        fr(sx + 6, sy + 8 + bob, 12, 12, C.FOLLOWER)
        fr(sx + 7, sy + 3 + bob, 10, 8, C.CYAN)
        fr(sx + 4, sy + 14 + bob, 16, 6, C.PURPLE)
        if frame % 30 < 15 then
          fr(sx + 10, sy - 4, 3, 7, C.WHITE)
          fr(sx + 10, sy + 4, 3, 3, C.WHITE)
        end
        f.ox = sx
        f.oy = sy
      end
    end
  end
end

local function drawEnemy(e)
  if e.dead then return end
  local sx = e.x - cam.x
  local sy = e.y - cam.y
  if not inScreen(sx, sy) then return end
  local bob = (e.anim < 15) and 0 or 1
  local flash = (e.stunTimer > 0 and frame % 4 < 2)
  local dc
  if flash     then dc = C.WHITE
  elseif e.etype == E_BOSS then dc = C.BOSS
  elseif e.etype == E_KNIGHT then dc = C.ENEMY2
  elseif e.etype == E_SKULL then dc = C.WALL2
  else dc = C.ENEMY end

  if e.ox then eraseSpriteAt(e.ox - 2, e.oy - 10, 28, 36) end

  if e.etype == E_SLIME then
    fr(sx + 3, sy + 9 + bob, 18, 12, dc)
    fr(sx + 1, sy + 12 + bob, 22, 9, dc)
    fr(sx + 6, sy + 9 + bob, 4, 4, C.WHITE)
    fr(sx + 14, sy + 9 + bob, 4, 4, C.WHITE)
    fr(sx + 7, sy + 10 + bob, 3, 3, C.BLACK)
    fr(sx + 15, sy + 10 + bob, 3, 3, C.BLACK)
  elseif e.etype == E_SKULL then
    fr(sx + 4, sy + 4 + bob, 16, 14, dc)
    fr(sx + 3, sy + 7 + bob, 18, 9, dc)
    fr(sx + 6, sy + 7 + bob, 4, 4, C.BLACK)
    fr(sx + 14, sy + 7 + bob, 4, 4, C.BLACK)
    fr(sx + 6, sy + 15 + bob, 3, 4, C.WHITE)
    fr(sx + 11, sy + 15 + bob, 3, 4, C.WHITE)
    fr(sx + 16, sy + 15 + bob, 3, 4, C.WHITE)
  elseif e.etype == E_KNIGHT then
    fr(sx + 4, sy + 7 + bob, 16, 14, dc)
    fr(sx + 3, sy + 5 + bob, 18, 6, C.WALL2)
    fr(sx + 4, sy + 1 + bob, 16, 9, C.WALL2)
    fr(sx + 7, sy + 4 + bob, 10, 7, dc)
    fr(sx + 19, sy + 6 + bob, 4, 14, C.GUN)
  elseif e.etype == E_BOSS then
    local ph2 = (e.hp <= floor(e.maxHp / 2))
    local bc = ph2 and C.BLOOD or dc
    fr(sx + 1, sy + 3 + bob, 22, 20, bc)
    fr(sx, sy + 6 + bob, 24, 14, bc)
    fr(sx + 3, sy + bob, 6, 7, bc)
    fr(sx + 15, sy + bob, 6, 7, bc)
    if ph2 then fr(sx + 9, sy - 3 + bob, 6, 9, bc) end
    fr(sx + 4, sy + 7 + bob, 6, 6, C.WHITE)
    fr(sx + 14, sy + 7 + bob, 6, 6, C.WHITE)
    fr(sx + 5, sy + 8 + bob, 5, 5, C.RED)
    fr(sx + 15, sy + 8 + bob, 5, 5, C.RED)
    fr(sx + 6, sy + 15 + bob, 12, 4, C.BLACK)
    fr(sx + 7, sy + 16 + bob, 3, 3, C.WHITE)
    fr(sx + 14, sy + 16 + bob, 3, 3, C.WHITE)
  end

  -- HP bar
  local barW = 20
  local hpW = max(1, floor(barW * e.hp / e.maxHp))
  fr(sx + 2, sy - 5, barW, 3, C.DARK)
  fr(sx + 2, sy - 5, hpW, 3, e.etype == E_BOSS and C.BOSS or C.ENEMY)

  e.ox = sx
  e.oy = sy
end

local function drawPlayer()
  local sx = P.x - cam.x
  local sy = P.y - cam.y

  if P.ox then eraseSpriteAt(P.ox - 6, P.oy - 8, 44, 40) end

  fr(sx + 4, sy + 20, 16, 4, C.SHADOW)

  if P.ritual and frame % 6 < 3 then
    fr(sx - 3, sy - 3, TILE + 6, TILE + 6, C.RITUAL)
  end

  fr(sx + 4, sy + 12, 16, 12, C.PURPLE)
  fr(sx + 3, sy + 14, 18, 9, C.PURPLE)

  local hcol
  if P.invTimer > 0 and frame % 4 < 2 then hcol = C.WHITE
  elseif P.ritual then hcol = C.RITUAL
  else hcol = C.PLAYER end
  fr(sx + 6, sy + 3, 12, 12, hcol)

  fr(sx + 7, sy + 6, 3, 3, C.BLACK)
  fr(sx + 14, sy + 6, 3, 3, C.BLACK)

  fr(sx + 4, sy, 16, 4, C.DARK)
  fr(sx + 7, sy - 4, 10, 6, C.DARK)

  if P.facing == "right" then
    fr(sx + 18, sy + 12, 8, 4, C.GUN)
    fr(sx + 15, sy + 10, 6, 6, C.GUN)
  elseif P.facing == "left" then
    fr(sx - 2, sy + 12, 8, 4, C.GUN)
    fr(sx + 3, sy + 10, 6, 6, C.GUN)
  elseif P.facing == "up" then
    fr(sx + 12, sy - 3, 4, 8, C.GUN)
    fr(sx + 10, sy + 3, 6, 6, C.GUN)
  elseif P.facing == "down" then
    fr(sx + 12, sy + 18, 4, 8, C.GUN)
    fr(sx + 10, sy + 14, 6, 6, C.GUN)
  end

  if P.shootTimer > 8 then
    local fx, fy = sx + 12, sy + 12
    if  P.facing == "right" then fx = sx + 26 fy = sy + 13
    elseif P.facing == "left" then fx = sx - 4 fy = sy + 13
    elseif P.facing == "up"  then fx = sx + 13 fy = sy - 6
    elseif P.facing == "down" then fx = sx + 13 fy = sy + 26 end
    fr(fx - 2, fy - 2, 6, 6, C.GOLD)
    fr(fx, fy, 3, 3, C.WHITE)
  end

  if P.followers > 0 then
    fr(sx + 14, sy - 8, 12, 8, C.FOLLOWER)
    pr(sx + 16, sy - 7, tostring(P.followers), C.BLACK)
  end

  P.ox = sx
  P.oy = sy
end

local function drawRecruitedFollowers()
  local fi = 0
  for _, f in ipairs(followers) do
    if f.recruited then
      local ox = (fi % 3 - 1) * TILE
      local oy = TILE * (1 + floor(fi / 3))
      local sx = P.x + ox - cam.x
      local sy = P.y + oy - cam.y
      local bob = (frame + fi * 7) % 20 < 10 and 0 or 1
      if inScreen(sx, sy) then
        fr(sx + 6, sy + 8 + bob, 12, 12, C.FOLLOWER)
        fr(sx + 7, sy + 3 + bob, 10, 8, C.CYAN)
        fr(sx + 4, sy + 14 + bob, 16, 6, C.PURPLE)
      end
      fi = fi + 1
    end
  end
end

local function drawProjectiles()
  for _, p in ipairs(projectiles) do
    local sx = floor(p.x - cam.x)
    local sy = floor(p.y - cam.y)
    if sx > 0 and sx < SW and sy > 0 and sy < SH then
      if abs(p.vx) > abs(p.vy) then
        fr(sx - 3, sy - 1, 7, 3, C.BULLET)
      else
        fr(sx - 1, sy - 3, 3, 7, C.BULLET)
      end
      fr(sx, sy, 3, 3, C.WHITE)
      p.ox = sx - 3
      p.oy = sy - 3
    end
  end
end

local function drawParticles()
  for _, p in ipairs(particles) do
    local sx = floor(p.x - cam.x)
    local sy = floor(p.y - cam.y)
    local sz = max(1, p.sz)
    if sx > 0 and sx < SW and sy > 0 and sy < SH then
      fr(sx, sy, sz, sz, p.col)
      p.ox = sx
      p.oy = sy
    end
  end
end

-- ============ HUD ============
local function drawHUD()
  fr(0, 0, SW, HUD_H, C.UI_BG)
  fr(0, HUD_H, SW, 1, C.WALL2)

  setTextSize(1)

  -- HP hearts
  pr(6, 8, "HP", C.WHITE)
  for i = 1, P.maxHp, 2 do
    local hx = 28 + (i - 1) * 9
    if i + 1 <= P.hp then
      fr(hx, 5, 8, 10, C.UI_BAR)
      fr(hx - 1, 8, 10, 6, C.UI_BAR)
    elseif i <= P.hp then
      fr(hx, 5, 4, 10, C.UI_BAR)
      fr(hx - 1, 8, 5, 6, C.UI_BAR)
    else
      fr(hx, 5, 8, 10, C.DARK)
      fr(hx - 1, 8, 10, 6, C.DARK)
    end
  end

  -- XP bar
  local xbx = 160
  pr(xbx, 8, "XP", C.UI_BAR2)
  fr(xbx + 20, 9, 80, 8, C.DARK)
  local xpW = floor(80 * P.xp / P.xpNext)
  if xpW > 0 then fr(xbx + 20, 9, xpW, 8, C.UI_BAR2) end
  pr(xbx + 20, 18, "Lv" .. P.level, C.UI_BAR2)

  -- Gold
  fr(280, 6, 10, 10, C.GOLD)
  fr(281, 7, 8, 8, C.WHITE)
  pr(294, 8, tostring(P.gold), C.GOLD)

  -- Followers
  pr(360, 8, "Flw:" .. P.followers, C.FOLLOWER)

  -- Faith
  pr(440, 8, "Fth:" .. P.faith, C.RITUAL)

  -- Ritual
  if P.ritual then
    local rt = floor(P.ritualTimer / 60)
    local pulseCol = frame % 20 < 10 and C.RITUAL or C.PURPLE
    fr(520, 3, 100, 22, pulseCol)
    pr(524, 8, "RITUAL " .. rt .. "s", C.WHITE)
  end

  -- Kills
  pr(SW - 80, 8, "K:" .. P.kills, C.ENEMY)

  -- Controls hint
  pr(6, SH - 14, "WASD:Move SPACE:Shoot ESC:Menu", C.WALL2)

  -- Flash message
  if flashTimer > 0 then
    local fw = #flashMsg * 6
    local fx2 = floor((SW - fw) / 2)
    local fy2 = floor(SH / 2) - 10
    fr(fx2 - 4, fy2 - 2, fw + 8, 14, C.BLACK)
    if flashTimer % 10 < 5 then
      fr(fx2 - 4, fy2 - 2, fw + 8, 14, C.UI_BG)
      pr(fx2, fy2, flashMsg, flashCol)
    end
  end
end
